import { Component,OnInit, OnDestroy ,Inject} from '@angular/core';

import { LoginService } from './login.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [],
})
export class AppComponent {
  title = 'app works!';
  accessToken='';
  isLoggedIn:boolean;
 constructor( private _loginService: LoginService ){
   

   }
  ngOnInit() {
  this._loginService.login();
}
  onclicklogin(){
    //this._loginService.login();
  }
onclicklogout(){
    this._loginService.logout();
  }
  onclickgetaccestoken(){
    this.accessToken = this._loginService.getAccessToken();

  }
  onclickisloggedin(){
    this.isLoggedIn = this._loginService.isLoggedIn();
  }
}
