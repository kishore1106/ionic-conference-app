import { Injectable } from '@angular/core';
import { Iloginconfig } from './iloginconfig';

@Injectable()
export class LoginService {
  CLIENT_ID :string= "";//ESST_Webportal_client ForestProHarvest_client
	LOGIN_URL :string= "";
	LOGOUT_URL:string = "";
	REDIRECT_URI :string= "";
  //isLoggedIn:boolean = false;
  accessToken:string;
  constructor() { 
  
  }

  config(config: Iloginconfig) {
    this.CLIENT_ID = config.CLIENT_ID;
	  this.LOGIN_URL = config.LOGIN_URL;
	  this.LOGOUT_URL = config.LOGOUT_URL;
	  this.REDIRECT_URI = config.REDIRECT_URI;
  }
  
  private initImplicitFlow() {
		//redirect to get access_token
		var scope = encodeURIComponent("openid profile");
		var state = encodeURIComponent(window.location.href.replace(/&/g, ";"));
		var redirect = encodeURIComponent(this.REDIRECT_URI);
		var redirectToUrl = this.LOGIN_URL + "?client_id=" + this.CLIENT_ID + "&scope=" + scope + "&response_type=token&pfidpadapterid=OAuthAdapterInstanceBaseOIDC"
			+ "&redirect_uri=" + redirect + "&client_id=" + this.CLIENT_ID + "&state=" + state;
		window.location.href = redirectToUrl;
	
	}
  /* Check whether access_token is generated  method starts here */
private	setAccessToken() {
		let accessData = this.parseUrl(window.location.hash);
        console.log('Access data at set', accessData);
    
        accessData.forEach(data => {
            if (data.key === '#access_token') {
                this.accessToken = data.value;
                 console.log("access token set ***",this.accessToken);
            }
        });
        if (this.accessToken) {
            sessionStorage.setItem('accessToken', this.accessToken);
           console.log("this.isLoggedIn",this.isLoggedIn);
        }
	}
  /* Parse the url method starts */
 private	parseUrl(url) {

		var parameters = url.split('&');
		var result = parameters.map((parameter) => {
			var item = parameter.split(/=(.*)/);
			return {
				key: item[0],
				value: item[1]
			};
		});
		return result;
	}


	/* Parse the url method ends */
  login():void{
    //console.log('reached login');
    if(this.isLoggedIn()){
       this.setAccessToken();
    }
    else{
      this.initImplicitFlow();
    }
  }
  logout(): void {
    if(this.isLoggedIn()){
    if (sessionStorage.getItem('accessToken')) {
            //console.log("logout", sessionStorage.getItem('accessToken'));
            sessionStorage.removeItem('accessToken');
    }
     this.accessToken = '';
     event.preventDefault();
     window.location.href=this.LOGOUT_URL;
  }
  }
  getAccessToken(){
    return this.accessToken;
  }

  isLoggedIn(): boolean {
    return this.accessToken ? true: sessionStorage.getItem('accessToken') ? true : this.isAcessTokenAvailableInURL() ? true: false;

  }

 private isAcessTokenAvailableInURL():boolean{
  	let accessData = this.parseUrl(window.location.hash);
    let isAvailableAtURL = false;
        console.log('Access data', accessData);
            accessData.forEach(data => {
            if (data.key === '#access_token') {
                isAvailableAtURL = true;
                return false;
            }
            if (data.key === 'error') {

                return false;
            }
            if (data.key === "" &&  !data.value ) {
               return false;
            }
        });
        return isAvailableAtURL;
}

}
