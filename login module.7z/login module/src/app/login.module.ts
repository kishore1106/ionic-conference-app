import {CommonModule} from '@angular/common'
import { NgModule,ModuleWithProviders } from '@angular/core';
import { LoginService } from './login.service';
import { Iloginconfig } from './iloginconfig';

@NgModule({
  declarations: [ ],
  imports: [  CommonModule  ],
  providers: []
  //exports: [ LoginService ]
})
export class LoginModule {
  
  static forRoot(config: Iloginconfig): ModuleWithProviders {
    return {
      ngModule: LoginModule,
      providers: [
        {
          provide: LoginService, 
          useFactory: ()=> { 
            let loginService: LoginService = new LoginService();
            loginService.config(config);
            return loginService;
          }
        }
      ]
    };
  }
}
