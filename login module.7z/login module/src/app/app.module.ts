
import {CommonModule} from '@angular/common'
import { ModuleWithProviders } from '@angular/core';
import 'rxjs/add/operator/map';

import { LoginService } from './login.service';
import { LoginModule } from './login.module';
import { Iloginconfig } from './iloginconfig';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';


let config = <Iloginconfig>{
    LOGIN_URL :"https://fedloginqa.cat.com/as/authorization.oauth2",
	LOGOUT_URL : "",
	REDIRECT_URI : "http://localhost:8080/",
    CLIENT_ID : "ESST_Webportal_client"
}
@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    LoginModule.forRoot(config)
  ],
  providers: [  ],
  bootstrap: [ AppComponent ]
})
export class AppModule { }




