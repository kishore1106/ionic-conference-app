export interface Iloginconfig {
    LOGIN_URL :string;
	LOGOUT_URL:string;
	REDIRECT_URI :string;
    CLIENT_ID :string;
}
