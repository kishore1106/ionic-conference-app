package com.webportal;

/**
 * Created by amarendra on 27/03/16.
 */
class Person {

	private String personName;

	public String getPersonName() {
		return personName;
	}
}
