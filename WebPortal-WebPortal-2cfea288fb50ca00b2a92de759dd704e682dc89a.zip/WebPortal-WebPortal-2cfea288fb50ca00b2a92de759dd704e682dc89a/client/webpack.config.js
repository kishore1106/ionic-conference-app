var path = require('path');
var HtmlWebpackPlugin = require('html-webpack-plugin');
var webpack = require('webpack');

module.exports = {
	context: path.resolve('app'),
	entry: "./main_index.ts",
	output: {
		path: path.resolve('dist'),		
		filename: "appBundle.js"
	},

	devServer: {
		contentBase: 'app'
	},
	watch: true,
	module: {
		loaders: [
			{
				test: /\.ts$/,
				exclude: /node_modules/,
				loader: "ts-loader"
			},
            {
				test: /\.css$/,
				exclude: /node_modules/,
				loader: "raw-loader!style-loader!css-loader"
			},
			{
				test: /\.scss$/,
				exclude: /node_modules/,
				loader: "raw-loader!style-loader!css-loader!sass-loader"
			},
            {
                test: /\.eot(\?v=\d+\.\d+\.\d+)?$/,
                loader: "file"
            },
            {
                test: /\.(woff|woff2)$/,
                loader: "url?prefix=font/&limit=5000"
            },
            {
                test: /\.ttf(\?v=\d+\.\d+\.\d+)?$/,
                loader: "url?limit=10000&mimetype=application/octet-stream"
            },
            {
                test: /\.svg(\?v=\d+\.\d+\.\d+)?$/,
                loader: "url?limit=10000&mimetype=image/svg+xml"
            },
			{
				test: /\.html$/,
				exclude: /node_modules/,
				loader: 'raw-loader'
			}

		]
	},
	plugins: [
        new HtmlWebpackPlugin({
            template: './index.html',
            inject: 'body',
            hash: true
        }),
	]
	,

	resolve: {
		extensions: ['', '.js', '.es6', '.ts']
	}


}