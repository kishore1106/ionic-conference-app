import {Component, OnInit, Input} from 'angular2/core';
import {RouteConfig, ROUTER_DIRECTIVES, RouteParams} from 'angular2/router';
import {ProjectDetailHeaderComponent} from './../projectDetailHeader/projectDetailHeader.component';
import {ProjectSidePanelComponent} from './../projectSidePanel/projectSidePanel.component';
import {ProjectDetailContentComponent} from './../projectDetailContent/projectDetailContent.component';
import {ProjectDetailProgressComponent} from './../projectDetailProgress/projectDetailProgress.component';
import {ProjectDetailCommentComponent} from './../projectDetailComment/projectDetailComment.component';
import {ProjectService} from './../shared/project.service';
import {Project} from './../project/project';
import {donutchart} from './../chart/progresschart.component';

@Component({
	selector: 'projectDetails',
	template:require('./main_projectDetails.html'),
	styleUrls: ['./styles/css/main_projectDetails.css'],
	directives: [ProjectDetailHeaderComponent, ProjectSidePanelComponent, 
				ProjectDetailContentComponent, ProjectDetailProgressComponent,
		        ProjectDetailCommentComponent, donutchart]
})

export class MainProjectDetailsComponent {

	project: Project;

	constructor(private _projectService: ProjectService,
		private _routeParams: RouteParams) {
	}
	ngOnInit() {

		let pid = this._routeParams.get('id');
		let projectsData: Project[];
		var that = this;
		this._projectService.getProject().subscribe((projects: Project[]) => this.project = projects.filter((project: Project) => project.project_id === pid)[0]);
	
	}
}
