/// <reference path="./../../typings/tsd.d.ts" />
import {Component, OnInit,Input} from 'angular2/core';
import {Router} from 'angular2/router';
import {ProjectService} from './../shared/project.service';
import {Project} from './project';
import {MainProjectDetailsComponent} from './../main_projectDetails/main_projectDetails.component';
import * as d3 from 'd3';
import {donutchart} from './../chart/progresschart.component';

@Component({
  selector: 'project-list',
  template: require('./project.html'),
  styleUrls : ['./styles/css/project.css'],
  directives : [donutchart]
})

export class ProjectComponent {
	
  selectedProject: Project[];

  @Input() projects: Project[];


  constructor(private _projectService: ProjectService, private _router: Router) {
    console.log(d3);
  }

  goToProjectDetail(project: Project) {
	  this._router.navigate(['ProjectDetail', { id: project.project_id }]);
  }
 

}