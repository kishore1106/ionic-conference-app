export interface Project {
	project_id: string;
	project_name: string;
	project_lead: string;
	project_info: string;
	start_date: string;
	end_date: string;
	status: any;
}

