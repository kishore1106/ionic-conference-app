export interface People {

	cwsid: string;
	person_image: string; //type must be image
	first_name: string;
	last_name: string;
	work_number: number;
	mob_num: number;
	email: string;
	role: string;
}
