import {Component, OnInit, Input} from 'angular2/core';
import {Router} from 'angular2/router';
import {PeopleService} from './../shared/people.service';
import {People} from './people';
import {FilterComponent} from './../filter/filter.component';

@Component({
  selector: 'people-list',
  template: require('./people.html'),
  styleUrls : ['./styles/css/people.css'],
  
})

export class PeopleComponent {
  @Input() peopleArray: People[];
  selectedPeople: People;

  constructor(private _peopleService: PeopleService) {

     }

 /* getPeople() {
    this._peopleService.getpeople().subscribe((proj) => this.people = proj);

  }
*/
 // ngOnInit() {
    //this.getPeople();
  //}

  onSelect(people:People) {
    if (people.cwsid != "invalid")
       this.selectedPeople = people;
    
    }   
  }
