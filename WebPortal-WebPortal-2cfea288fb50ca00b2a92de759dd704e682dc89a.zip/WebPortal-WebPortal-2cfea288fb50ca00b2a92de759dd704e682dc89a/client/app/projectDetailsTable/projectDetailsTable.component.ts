import {Component, OnInit, Input} from 'angular2/core';
import {Project} from './../project/project';
import {Collapse} from './../myCollapse.directive';


@Component({
	selector: 'project-detail-table',
	template:require( './projectDetailsTable.html'),
	styleUrls: ['./styles/css/projectDetailContent.css'],
	directives: [Collapse]
})

export class ProjectDetailTableComponent {

	@Input() project: Project[];

	constructor() { }
}
