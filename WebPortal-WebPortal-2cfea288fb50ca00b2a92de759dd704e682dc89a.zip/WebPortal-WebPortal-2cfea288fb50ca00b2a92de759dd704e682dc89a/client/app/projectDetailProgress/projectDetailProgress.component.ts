import {Component, OnInit, Input} from 'angular2/core';
import {Project} from './../project/project';
import * as d3 from 'd3';
import {donutchart} from './../chart/progresschart.component';


@Component({
	selector: 'projectDetail-progress',
	template:require( './projectDetailProgress.html'),
	styleUrls: ['./styles/css/projectDetailProgress.css'],
	directives: [donutchart]
})

export class ProjectDetailProgressComponent {

	@Input() project: Project[];
	
	constructor() { }
}
