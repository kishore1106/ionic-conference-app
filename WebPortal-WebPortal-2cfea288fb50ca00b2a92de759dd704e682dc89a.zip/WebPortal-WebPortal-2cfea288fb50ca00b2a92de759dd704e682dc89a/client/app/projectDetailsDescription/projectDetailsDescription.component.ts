import {Component, OnInit, Input} from 'angular2/core';
import {Project} from './../project/project';
import {Collapse} from './../myCollapse.directive';


@Component({
	selector: 'project-detail-description',
	template: require('./projectDetailsDescription.html'),
	styleUrls: ['./styles/css/projectDetailContent.css'],
	directives: [Collapse]
})

export class ProjectDetailDescriptionComponent {

	@Input() project: Project[];

	constructor() { }
}
