export interface Dashboard {
	dashboard_icon: string;
	name: string;
}