import {Component, OnInit} from 'angular2/core';
import {Router} from 'angular2/router';



@Component({
	selector: 'dashboard',
	template: require('./dashboard.html'),
	styleUrls: ['./Dashboard/dashboard.css']

})

export class DashboardComponent {

	// public myValue: boolean = false;
	constructor(private _router: Router) { }

	goToProject() {
		this._router.navigate(['Projects']);
	}

}
	
