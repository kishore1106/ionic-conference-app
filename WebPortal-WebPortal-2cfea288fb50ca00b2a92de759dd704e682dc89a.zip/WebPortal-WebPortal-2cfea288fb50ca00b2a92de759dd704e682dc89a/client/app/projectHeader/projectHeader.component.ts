import {Component, OnInit, Input} from 'angular2/core';
import {Collapse} from './../myCollapse.directive';

@Component({
	selector: 'project-header',
	template:require('./projectHeader.html'),
	styleUrls: ['./styles/css/header.css'],
	directives: [Collapse]
})

export class ProjectHeaderComponent {
	constructor() { }
	public isCollapsed: boolean = true;
	// insideProjects: boolean = true;
}

