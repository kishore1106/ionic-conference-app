import {Component, OnInit, Input, Output, EventEmitter} from 'angular2/core';
import {Pipe, PipeTransform} from 'angular2/core';  
import {Router} from 'angular2/router';
import {SectionService} from './../shared/section.service';
import {Section} from './section';


@Pipe({
    name: "searchText"
})

class SearchTextPipe implements PipeTransform {
    transform(section: any, args: string[]) {
        let [searchKey, label] = args;
        if (searchKey == '' || searchKey == undefined) {
            return section;
        }
        return section.filter((section: any) => section[label].indexOf(searchKey) !== -1);
    }
}


@Component({
  selector: 'section-list',
   pipes: [SearchTextPipe],
  template:require('./section.html'),
  styleUrls: ['./styles/css/people.css']
})

export class SectionComponent  { 
  selectedSection: string[];
  toggleSelectState: string = 'none';
  multiselectHeader: string[];

  @Input() sectionArray: Section[];
  @Input('collection') collection: any;
  @Input('multiple') multiple: boolean;
  @Input('label') label: string;
  @Input('header') header: string[];

  @Input('mutiselectModel') mutiselectModel: any;
 
  @Output() selected = new EventEmitter<String[]>(); 

  constructor(private _peopleService: SectionService) {
  }
  

  ngOnInit():any {
    this.multiselectHeader = this.header;
    
  }

  toggleSelect() {
    if (this.toggleSelectState == 'none') {
      this.toggleSelectState = 'block';
    } else {
      this.toggleSelectState = 'none';
    }
  }



  checkAll() {
    if (this.multiple != true) {
      return;
    }
    this.collection.forEach((t: any) => t.checked = true);
    this.updateMultipleModel();
  }

  unCheckAll() {
    this.collection.forEach((t: any) => t.checked = false);
    this.multiselectHeader = this.header;
    this.updateMultipleModel();
  }

  selectItem(section: any) {
    section.checked = !section.checked;
    this.updateMultipleModel();
  }

  updateMultipleModel() {
    this.mutiselectModel = [];
    this.multiselectHeader = ["Section"];
    for (let section of this.collection) {
    if (section.checked) {
        this.mutiselectModel.push(section);
        this.multiselectHeader = this.mutiselectModel.map((multiselect: any) => multiselect.section_name);
      }
    }
    this.selectedSection = this.multiselectHeader;
  if (this.selectedSection[0] == 'Section') {
    this.selectedSection = [];
       }
  this.selected.emit(this.selectedSection);
  }
}
