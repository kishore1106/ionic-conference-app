import {Team} from './../team/team';

export interface Section {
	section_id: string;
	section_name: string;
	section_lead_name: string;
	teams: Team[];
}

