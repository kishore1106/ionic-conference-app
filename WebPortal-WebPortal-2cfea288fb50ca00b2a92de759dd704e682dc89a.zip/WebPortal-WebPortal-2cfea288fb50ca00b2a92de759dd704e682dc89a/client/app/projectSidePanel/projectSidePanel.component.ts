import {Component, OnInit} from 'angular2/core';

@Component({
	selector: 'projectSide-Panel',
	template:require('./projectSidePanel.html'),
	styleUrls: ['./styles/css/projectSidePanel.css']
})

export class ProjectSidePanelComponent {
	constructor() { }
}
