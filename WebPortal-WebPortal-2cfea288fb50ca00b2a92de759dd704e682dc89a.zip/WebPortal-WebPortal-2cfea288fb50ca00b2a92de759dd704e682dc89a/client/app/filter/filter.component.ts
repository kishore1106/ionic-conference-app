import {Component, OnInit} from 'angular2/core';
import {RouteConfig, ROUTER_DIRECTIVES} from 'angular2/router';
import {ProjectComponent} from './../project/project.component';
import {SectionComponent} from './../section/section.component';
import {TeamComponent} from './../team/team.component';
import {ProjectCardComponent} from './../projectCard/projectCard.component';
import {Section} from './../section/section';
import {Team} from './../team/team';
import {Project} from './../project/project';
import {ProjectCard} from './../projectCard/projectCard';
import {SectionService} from './../shared/section.service';
import {ProjectCardService} from './../shared/projectcard.service';
import {ProjectHeaderComponent} from './../projectHeader/projectHeader.component';



@Component({
	selector: 'filter-list',
	template: require('./filter.html'),
	styleUrls: ['./styles/css/filter.css'],
	directives: [ProjectComponent, SectionComponent, TeamComponent, ProjectCardComponent, ProjectHeaderComponent],
	providers: [[SectionService, ProjectCardService]]
})

export class FilterComponent implements OnInit {

	section: Section[];
	sectionArray: Section[];
	teams: Team[];
	projects: Project[];
	projectCardArray: ProjectCard[];
	multiselectModel1: Array<any> = [];	
	toggleSelectState: string = 'none';
	// insideProjects: boolean = true;



	constructor(private _sectionService: SectionService, private _projectcardService: ProjectCardService) { 
	}

	getSection() {
		this._sectionService.getsection().subscribe((sectionArray) => this.sectionArray = sectionArray);

	}

	getprojectcard() {
		this._projectcardService.getprojectcard().subscribe((projectArray) =>this.projectCardArray = projectArray);
	}

	toggleSelect() {
		if (this.toggleSelectState == 'none') {
			this.toggleSelectState = 'block';
		} else {
			this.toggleSelectState = 'none';
		}
	}

	selectedSection(sectionId:any[]) {
		if (sectionId.length > 0 ) {

			let teamArray: Array<Team[]> = [];
			// sectionId.forEach((section) => {
			// 	this.section = this.sectionArray.filter((sections) => 
			// 							sections.section_name === section);
			// 	this.teams = this.section[0].teams;
			// 	teamArray.push(this.teams);

			// });

			teamArray = this.generatedArray(sectionId,this.section,this.teams,
				this.sectionArray,'section_name','teams',teamArray);


			this.teams = this.reduceMethod(this.teams, teamArray);
			
			let projectArray: Array<Project[]> = [];

			projectArray = this.projectArrayMethod(this.teams);

			this.projects = this.reduceMethod(this.projects, projectArray);

			this.statsResult();

		}
		else
		{
			this.teams = [];
			this.projects = [];
			this.projectCardArray = [];
			this.getprojectcard();
		}
	}


	selectedTeam(teamId:any[]) {
		
		if((this.teams.length > 0) && (teamId.length>0))
		{
			let selectedTeam: Team[];
			let getProjectArray: Array<Project[]> = [];

			// teamId.forEach((team) => {
				
			// 	selectedTeam = this.teams.filter((teams) =>
			// 		teams.team_name === team);

			// 	this.projects = selectedTeam[0].projects;

			// 	projectArray.push(this.projects);

			// });

			getProjectArray = this.generatedArray(teamId, selectedTeam, this.projects,
				this.teams, 'team_name', 'projects', getProjectArray);

			this.projects = this.reduceMethod(this.projects,getProjectArray);
			
			this.statsResult();
		}
		else
		{

			this.teams = this.reduceMethod(this.teams, this.teams);
			
			let projectArray: Array<Project[]> = [];

			projectArray = this.projectArrayMethod(this.teams);

			this.projects = this.reduceMethod(this.projects, projectArray);

			this.statsResult();
			
		}
		
	}
	ngOnInit() {
		this.getSection();
		this.getprojectcard();

		
	}


	generatedArray(id:any[], type:any[], 
		dependentType:any[], typeArray:any[],
		typeField:any, depTypField: any,
		depArray:any[]) {
		
		id.forEach((idVar) => {
			type = typeArray.filter((field) =>
				field[typeField] === idVar);
			
			dependentType = type[0][depTypField];
			
			depArray.push(dependentType);

		});
		return depArray;
	}

	statsResult() {

		this.projectCardArray.forEach((projectCard) => {

			projectCard.stats = 0;
		});

		this.projectCardArray[0].stats = this.projects.length;
		this.projects.forEach((project) => {

			if (project.status === "0") {
				this.projectCardArray[3].stats += 1;
			}
			else if (project.status === "100") {
				this.projectCardArray[2].stats += 1;
			}
			else {
				this.projectCardArray[1].stats += 1;
			}
		});
	}

	reduceMethod(type:any[],depArray:any[]) {
		
		type = depArray.reduce((a,b) => {
			return a.concat(b);
		},[])

		return type;
	}

	projectArrayMethod(type:any[]) {

		let projectArray: Array<Project[]> = [];

		let length = type.length;

		for (var index = 0; index < length; index++) {
			projectArray.push(type[index].projects);
		}
		return projectArray;
	}
}