import {Component, OnInit} from 'angular2/core';

@Component({
	selector: 'projectDetail-comment',
	template: require('./projectDetailComment.html'),
	styleUrls: ['./styles/css/projectDetailComment.css']
})

export class ProjectDetailCommentComponent {
	constructor() { }
}
