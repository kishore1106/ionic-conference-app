import {Component, OnInit, Input} from 'angular2/core';
import {Project} from './../project/project';
import {ProjectDetailTableComponent} from './../projectDetailsTable/projectDetailsTable.component';
import {ProjectDetailDescriptionComponent} from './../projectDetailsDescription/projectDetailsDescription.component';




@Component({
	selector: 'projectDetail-content',
	template: require('./projectDetailContent.html'),
	styleUrls: ['./styles/css/projectDetailContent.css'],
	directives: [ProjectDetailTableComponent, ProjectDetailDescriptionComponent]


})

export class ProjectDetailContentComponent {

	@Input() project: Project[];
	
	constructor() { }
}
