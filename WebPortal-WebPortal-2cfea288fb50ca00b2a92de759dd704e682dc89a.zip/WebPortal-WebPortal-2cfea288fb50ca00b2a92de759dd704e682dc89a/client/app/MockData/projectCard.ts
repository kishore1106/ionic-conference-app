import { ProjectCard } from './../projectCard/projectCard';

export var ProjectCardList: ProjectCard[] =[
	{
		"icon": "images/Menu.svg",
		"title": "Total",
		"color": "DarkBlue",
		"stats": 0
	},
	{
		"icon":"images/globe.svg",
		"title":"In Progress",
		"color": "Green",
		"stats": 0
	},
	{
		"icon": "images/clipboard.svg",
		"title": "Completed",
		"color": "Peach",
		"stats": 0
	},
	{
		"icon": "images/arrows.svg",
		"title": "To Start",
		"color": "LightBlue",
		"stats": 0
	}


];