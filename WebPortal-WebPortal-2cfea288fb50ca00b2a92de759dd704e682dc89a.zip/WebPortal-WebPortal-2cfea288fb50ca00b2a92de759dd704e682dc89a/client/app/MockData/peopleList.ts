import { People } from './../people/people';

export var PeopleList: People[] =[

    { 	"cwsid": "paramn1",
 		"person_image":"nivethitha",
  		"first_name":"NIVETHITHA",
   		"last_name":"PARAMASIVAM",
	  	"work_number":4439964297,
		"mob_num":9952890305,
		"email":"paramasivam_nivethitha@cat.com",
		"role":"intern"
		

	},

    { 	"cwsid": "cheems",
 		"person_image":"seerat",
  		"first_name":"SEERAT",
   		"last_name":"CHEEMA",
	  	"work_number":4439964305,
		"mob_num":9952890305,
		"email":"cheema_seerat@cat.com",
		"role":"intern"
		

	}
]