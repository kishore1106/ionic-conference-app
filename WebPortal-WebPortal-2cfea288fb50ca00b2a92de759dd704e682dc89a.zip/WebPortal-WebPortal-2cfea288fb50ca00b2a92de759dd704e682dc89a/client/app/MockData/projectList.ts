import { Project } from './../project/project';

export var ProjectList: Project[] = [
	{
		"project_id": "123",
		"project_name": "WebPortal",
		"project_lead": "ibrahim",
		"project_info": "portal for ACSD-ATS",
		"start_date": "01|02|16",
		"end_date": "31|05|16",
		"status": "100"
	},

	{
		"project_id": "456",
		"project_name": "ValueSelling",
		"project_lead": "ibrahim",
		"project_info": "portal for ACSD-ATS",
		"start_date": "01|01|16",
		"end_date": "31|03|16",
		"status": "0"
	},
	{
		"project_id": "356",
		"project_name": "EP-Residential",
		"project_lead": "Doss",
		"project_info": "portal for ACSD-ATS",
		"start_date": "01|02|16",
		"end_date": "31|05|16",
		"status": "90"
	},

	{
		"project_id": "165",
		"project_name": "CRM-I Support",
		"project_lead": "saran",
		"project_info": "portal for ACSD-ATS",
		"start_date": "01|01|16",
		"end_date": "31|03|16",
		"status": "70"
	},
	{

		"project_id": "520",
		"project_name": "olga",
		"project_lead": "subbu",
		"project_info": "phoenix",
		"start_date": "01|02|16",
		"end_date": "31|05|16",
		"status": "90"
	},


	{
		"project_id": "778",
		"project_name": "CatInspect",
		"project_lead": "subbu",
		"project_info": "phoenix",
		"start_date": "01|01|16",
		"end_date": "31|03|16",
		"status": "80"
	},

	{
		"project_id": "5",
		"project_name": "prod Analytics",
		"project_lead": "arun",
		"project_info": "isss",
		"start_date": "01-02-2016",
		"end_date": "31-05-2016",
		"status": "0"
	}


];
