import { Dashboard } from './../Dashboard/Dashboard';

export var dashboardList: Dashboard[] = [
	{
    "dashboard_icon": "images/Webportal_Home Page_Projects.svg",
    "name": "Projects",
	},
	{
    "dashboard_icon": "images/Webportal_Home Page_Quality.svg",
    "name": "Quality",
	},
	{
    "dashboard_icon": "images/Webportal_Home Page_Velocity.svg",
    "name": "Velocity",
	},
	{
    "dashboard_icon": "images/Webportal_Home Page_CI Ideas.svg",
    "name": "CI Ideas",
	},
	{
    "dashboard_icon": "images/Webportal_Home Page_Collaboration.svg",
    "name": "Collaboration",
	},
	{
    "dashboard_icon": "images/Webportal_Home Page_R&E Efficieny.svg",
    "name": "R&E Efficiency",
	},
	{
    "dashboard_icon": "images/Webportal_Home Page_Reports.svg",
    "name": "Reports",
	},
	{
    "dashboard_icon": "images/Webportal_Home Page_Dashboard.svg",
    "name": "Dashboard",
	}	
]
