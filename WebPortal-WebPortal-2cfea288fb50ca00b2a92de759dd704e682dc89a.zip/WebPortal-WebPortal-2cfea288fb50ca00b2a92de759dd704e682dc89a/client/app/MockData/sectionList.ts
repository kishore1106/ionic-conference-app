// import { Section } from './../section/section';

// export var SectionList: Section[] = [
//     {
// 		"section_id": "IMSS",
// 		"section_name": "IMSS",
// 		"section_lead_name": "Sridhar",
// 		"teams": [{
// 			"team_id": "CRM",
// 			"team_name": "CRM",
// 			"team_lead_name": "Doss",
// 			"projects": [{
// 				"project_id": "123",
// 				"project_name": "WebPortal",
// 				"project_lead": "ibrahim",
// 				"project_info": "portal for ACSD-ATS",
// 				"start_date": "01|02|16",
// 				"end_date": "31|05|16",
// 				"status": "100"
// 			},

// 				{
// 					"project_id": "456",
// 					"project_name": "ValueSelling",
// 					"project_lead": "ibrahim",
// 					"project_info": "portal for ACSD-ATS",
// 					"start_date": "01|01|16",
// 					"end_date": "31|03|16",
// 					"status": "0"
// 				},
// 				{
// 					"project_id": "356",
// 					"project_name": "EP-Residential",
// 					"project_lead": "Doss",
// 					"project_info": "portal for ACSD-ATS",
// 					"start_date": "01|02|16",
// 					"end_date": "31|05|16",
// 					"status": "90"
// 				},

// 				{
// 					"project_id": "165",
// 					"project_name": "CRM-I Support",
// 					"project_lead": "saran",
// 					"project_info": "portal for ACSD-ATS",
// 					"start_date": "01|01|16",
// 					"end_date": "31|03|16",
// 					"status": "70"
// 				}]

// 		},

// 			{
// 				"team_id": ".NET",
// 				"team_name": ".NET",
// 				"team_lead_name": "Mani",
// 				"projects": [{

// 					"project_id": "520",
// 					"project_name": "OLGA",
// 					"project_lead": "SUBBU",
// 					"project_info": "phoenix",
// 					"start_date": "01|02|16",
// 					"end_date": "31|05|16",
// 					"status": "90"
// 				},


// 					{
// 						"project_id": "778",
// 						"project_name": "CATINSPECT",
// 						"project_lead": "SUBBU",
// 						"project_info": "phoenix",
// 						"start_date": "01|01|16",
// 						"end_date": "31|03|16",
// 						"status": "80"
// 					}]
// 			}]
// 	},




//     {
// 		"section_id": "ISSS",
// 		"section_name": "ISSS",
// 		"section_lead_name": "Janavi",
// 		"teams": [{
// 			"team_id": "plweb",
// 			"team_name": "PLWEB",
// 			"team_lead_name": "vishnu",
// 			"projects": [{
// 				"project_id": "5",
// 				"project_name": "prod Analytics",
// 				"project_lead": "arun",
// 				"project_info": "isss",
// 				"start_date": "01|02|16",
// 				"end_date": "31|05|16",
// 				"status": "0"
// 			}]
// 		}
// 		]
// 	}
// ];