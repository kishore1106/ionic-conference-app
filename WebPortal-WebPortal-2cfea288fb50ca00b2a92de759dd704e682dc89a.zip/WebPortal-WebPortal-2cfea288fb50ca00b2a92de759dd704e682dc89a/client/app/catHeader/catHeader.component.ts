import {Component, OnInit} from 'angular2/core';
import {Collapse} from './../myCollapse.directive';

@Component({
	selector: 'cat-header',
	template: require('./catHeader.html'),
	directives: [Collapse]
})

export class CatHeaderComponent {
	constructor() { }
	public isCollapsed: boolean = true;
}
