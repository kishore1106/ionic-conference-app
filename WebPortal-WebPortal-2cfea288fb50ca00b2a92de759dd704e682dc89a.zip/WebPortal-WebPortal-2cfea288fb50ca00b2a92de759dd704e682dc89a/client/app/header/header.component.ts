import {Component, OnInit, Input} from 'angular2/core';
import {ProjectHeaderComponent} from './../projectHeader/projectHeader.component';
import {CatHeaderComponent} from './../catHeader/catHeader.component';
import {Collapse} from './../myCollapse.directive';

@Component({
	selector: 'header-portal',
	template: require('./header.html'),
	// styleUrls: ['./styles/css/header.scss'],
	directives: [ProjectHeaderComponent, CatHeaderComponent, Collapse]
})
export class HeaderComponent {
	constructor() {}
}
