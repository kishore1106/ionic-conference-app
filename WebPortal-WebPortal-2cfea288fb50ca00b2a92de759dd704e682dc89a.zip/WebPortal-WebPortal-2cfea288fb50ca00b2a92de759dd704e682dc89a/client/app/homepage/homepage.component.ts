import {Component, OnInit} from 'angular2/core';
import {RouteConfig, ROUTER_DIRECTIVES} from 'angular2/router';
import {ProjectService} from './../shared/project.service';
import {CatHeaderComponent} from './../catHeader/catHeader.component';
import {DashboardComponent} from './../Dashboard/dashboard.component';
import {ProjectCardComponent} from './../projectCard/projectCard.component';
import {ProjectComponent} from './../project/project.component';
import {MainComponent} from './../main_index/main.component';
import {FilterComponent} from './../filter/filter.component';
import {MainProjectDetailsComponent} from './../main_projectDetails/main_projectDetails.component';
import {ProjectHeaderComponent} from './../projectHeader/projectHeader.component';


@Component({
	selector: 'homepage',
	template: require('./homepage.html'),
	directives: [CatHeaderComponent, DashboardComponent, FilterComponent, MainProjectDetailsComponent, ROUTER_DIRECTIVES, ProjectHeaderComponent],
	providers: [ProjectService]
})

@RouteConfig([
		{ path: '', name: 'Homepage', component: DashboardComponent, useAsDefault: true },
		{ path: '/projects', name: 'Projects', component: FilterComponent },
		 { path: '/projectdetail/:id', name: 'ProjectDetail', component: MainProjectDetailsComponent }
])

export class HomepageComponent {
	
	constructor() {

	}
	
}
