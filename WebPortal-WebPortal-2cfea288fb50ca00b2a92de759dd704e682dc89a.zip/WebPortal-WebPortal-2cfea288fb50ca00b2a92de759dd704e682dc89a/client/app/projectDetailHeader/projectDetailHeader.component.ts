import {Component, OnInit} from 'angular2/core';

@Component({
	selector: 'projectDetail-header',
	template:require( './projectDetailHeader.html'),
	styleUrls: ['./styles/css/projectDetailHeader.css']
})

export class ProjectDetailHeaderComponent {
	constructor() { }
}
