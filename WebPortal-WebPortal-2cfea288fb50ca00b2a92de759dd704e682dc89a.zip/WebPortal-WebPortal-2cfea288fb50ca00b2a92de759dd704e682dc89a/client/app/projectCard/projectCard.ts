export interface ProjectCard {
	icon: string;
	title: string;
	color: string;
	stats: number;
}
