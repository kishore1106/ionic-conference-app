import {Component, OnInit, Input} from 'angular2/core';
import {ProjectCardService} from './../shared/projectcard.service';
import {ProjectCard} from './projectCard';

@Component({
	selector: 'project-card',
	template:require('./projectCard.html'),
	styleUrls: ['./styles/css/projectCard.css'],
	providers: [[ProjectCardService]]
})

export class ProjectCardComponent{

	@Input() projectCardArray: ProjectCard[];
	
	constructor(private _projectcardService: ProjectCardService) { 
		
	}
	
}