/// <reference path="./../../typings/tsd.d.ts" />
//our root app component
import {Component, Directive, ElementRef, Input, Attribute, OnInit, OnChanges, SimpleChange} from 'angular2/core';
import * as d3 from 'd3';
console.log(d3);


@Directive({
  selector: '[donut-graphs]'
})
export class DonutChart  {
  @Input() data: any;

  private tip: any = null;
  private bindId: string;
  private type: string;
  private responsive: boolean;
  private chartData: any;
  private horizontalData: any;
  private name: string = null;
  private drilldowndata: any = null;
  private addClass: any;
  //private stack: any = null;
  private margin: any;
  private width: number;
  private height: number;
  private drillDown: boolean;
  private title: string;
  private xAxis: any;
  private radius: any;
  private _innerRadius: number;
  private legendRectSize = 18;
  private legendSpacing = 4;
  private display: any;
  private tooltip: boolean;
  public click: { (msg: any): void };
  public hover: { (msg: any): void };
  public tooltipContent: { (msg: any): void };


  constructor(config: any) {

    this.chartData = config.data;
    this.bindId = config.id;
    this.type = config.type;
    this.responsive = (config.responsive && config.responsive == true) ? true : false;
    this.drillDown = (config.drillDown && config.drillDown === true) ? true : false;
    this.addClass = (config.class) ? config.class : "";
    this.margin = config.margin;
    this.width = config.width;
    this.height = config.height;
    this.xAxis = config.xAxis;
    this.title = config.title;
    this.display = config.display;
    this.tooltip = config.tooltip;

    this.init(config);
  }

  private addParentNode(data: any, parent: any) {
    for (var i = 0; i < data.length; i++) {
      if (parent) {
        data[i].parent = parent;
      }

      if (data[i].children && data[i].children.length > 0) {
        this.addParentNode(data[i].children, data);
      }
    }
  }

  private clearScreen() {
    d3.selectAll('#' + this.bindId + ' svg').remove();
    d3.selectAll('#' + this.bindId + ' div').remove();
    //d3.select('.d3-tip').remove(); 
  }

  private upLevel(display: any) {
    if (this.drilldowndata.length > 0) {
      if (this.drilldowndata[0].parent) {
        this.drawChart(this.drilldowndata[0].parent, display);
        this.drilldowndata = this.drilldowndata[0].parent;
      }
    }
  }

  private downLevel(data: any, display: any) {
    if (data.data.children) {
      this.drilldowndata = data.data.children;
      this.tip.hide();
      this.drawChart(data.data.children, display);
    }
  }

  private resizeChart() {
    this.width = window.innerWidth;
    this.drawChart(this.chartData, this.display);
  }

  private findProperty(arr: any, prop: any) {
    var newArr: any[] = [];
    for (var i = 0; i < arr.length; i++) {
      newArr.push(arr[i][prop]);
    }
    return newArr;
  }

  private drawChart(data: any, display: any) {
    this.radius = Math.min(this.width, this.height) / 2,
    this.clearScreen();

    //var color = d3.scale.ordinal().range(findProperty(data, 'color'));
    var color = d3.scale.category20();

    if (display === 'pie') {
      this._innerRadius = 0;
    }

    else {
      this._innerRadius = this.radius - 70;
    }

    var arc = d3.svg.arc().outerRadius(this.radius - 10).innerRadius(this._innerRadius);

    var pie = d3.layout.pie().sort(null)
    .value(function(d) {
      return d['value'];
    });

    /*this.tip = d3.tip()
    .attr('class', 'd3-tip')
    .offset([-10, 0])
    .html(
      function(d: any) {
        if (this.tooltipContent instanceof Function) {
          this.tooltipContent(d);
        }
        return '<strong>Year:</strong> <span style=color:red>' + d.data.label + '</span>';
      }
      );*/

    var div = d3.select('#' + this.bindId).append('div')
    .attr('class', 'div')
    .attr('align', 'center')
    .text(this.title);

    var svg = d3.select('#' + this.bindId).append('svg')
    .attr('width', this.width)
    .attr('height', this.height)
    .append('g')
    .attr('transform', 'translate(' + this.width / 2 + ',' + this.height / 2 + ')');

    var g = svg.selectAll('.arc').data(pie(data))
    .enter().append('g')
    .attr('class', 'arc');

    g.append('path')
    .attr('d', <any>arc)
    .style('fill', function(d) {
      return color(d.data['label']);
    })
    .on('click', (d, index) => {
      if (this.drillDown === true) {
        this.downLevel(d, display);
      }
      if (this.click instanceof Function) {
        this.click(d);
      }
    })
    .on('mouseover', (d) => {
      if (this.tooltip === true) {
        this.tip.show(d);
      }
      if (this.hover instanceof Function) {
        this.hover(d);
      }
    }).on('mouseout', (d) => {
      if (this.tooltip === true) {
        this.tip.hide(d);
      }
    });

    svg.call(this.tip);

    g.append('text')
    .attr('transform', (d) => { return 'translate(' + arc.centroid(<any>d) + ')'; })
    .attr('dy', '.35em')
    .text(function(d) { return d.data['label']; });

    d3.select('#pieback').on('click', () => {
      this.upLevel(display);
    });

    var svg1 = d3.select('#' + this.bindId)
    .append('svg')
    .attr('width', this.width / 2)
    .attr('height', this.height / 2)
    .append('g')
    .attr('transform', 'translate(' + (100) +
      ',' + (100) + ')');

    div = d3.select('#' + this.bindId).append('div')
    .attr('class', 'tooltip')
    .style('display', 'none');

    var legend = svg1.selectAll('.legend')
    .data(color.domain())
    .enter()
    .append('g')
    .attr('class', 'legend')
    .attr('transform', (d, i) => {
      let height = this.legendRectSize + this.legendSpacing;
      var offset = height * color.domain().length / 2;
      var horz = -2 * this.legendRectSize;
      var vert = i * height - offset;
      return 'translate(' + 0 + ',' + vert + ')';
    });

    legend.append('rect')
    .attr('width', this.legendRectSize)
    .attr('height', this.legendRectSize)
    .style('fill', color)
    .style('stroke', color)
    .on('mouseover', (d) => {
      this.over(div, d);
    })
    .on('mousemove', (d) => {
      this.move(div, d);
    })
    .on('mouseout', (d) => {
      this.out(div, d);
    });


    legend.append('text')
    .attr('x', this.legendRectSize + this.legendSpacing)
    .attr('y', this.legendRectSize - this.legendSpacing)
    .text(function(d) { return d; });
  }
  private over(div: any, d: any) {
    div.style('display', 'inline');
  }

  private move(div: any, d: any) {
    div.text(d)
    .style('left', (100 - 34) + 'px')
    .style('top', (100 - 12) + 'px');
  }


  private out(div: any, d: any) {
    div.style('display', 'none');
  }

  private init(JSON: any) {

    if (this.drillDown === true) {
      this.addParentNode(this.chartData, undefined);
    }

    this.drawChart(this.chartData, this.display);

    if (this.responsive === true) {
      d3.select(window).on('resize.' + this.bindId, () => {
        this.resizeChart();
      });
    }

  }
}

@Component({
  selector: 'my-donutcharts',
  directives: [DonutChart],
  template: `
  <div donut-graphs
  [data]="values"
  width="150px"
  height="100px">
  </div>
  `
})

export class donutcharts {
  values: any;
  @Input('status') status: number;
  constructor() {
  }

  ngOnInit() {
    //this.values = [this.status, 100 - this.status];
     this.values = [80, 20];
  }
}