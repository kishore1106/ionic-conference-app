/// <reference path="./../../typings/tsd.d.ts" />
//our root app component
import {Component, Directive, ElementRef, Input, Attribute, OnInit, OnChanges, SimpleChange} from 'angular2/core';
import * as d3 from 'd3';
console.log(d3);



@Directive({
  selector: '[donut-graph]'
})
export class DonutChart implements OnChanges {
  @Input() data: any;
  width: any;
  height: any;
  divs: any;


  constructor(
    private elementRef: ElementRef,
    @Attribute('width') width: any,
    @Attribute('height') height: any) {
    this.width = width;
    this.height = height;

    let el: any = this.elementRef.nativeElement;
    let graph: any = d3.select(el);

    this.divs = graph.
      append('svg')
      .attr("width", this.width)
      .attr("height", this.height)
      .append("g")
      .attr("transform", "translate(" + 100 + "," + 55 + ")")
      ;
  }

  ngOnChanges(changes: { [propertyName: string]: SimpleChange }) {
    let changedData = changes['data']
    this.data = changedData.currentValue;
    this.render(this.data);

  }

  render(newValue: any) {
    if (!newValue) return;

    
    let radius: number = Math.min(195,190) / 2;

    let color = d3.scale.category10();
    let colorvalues = ["#00cc00","#b3b3b3"]

    let pie = d3.layout.pie()
    .sort(null);

    let arc = d3.svg.arc()
    .innerRadius(radius - 65)
    .outerRadius(radius - 50);


    /*this.divs.selectAll("path").data(pie(newValue)).enter().append('path')
      .attr("fill", function(d:any, i:any): any { return color(i); })
      .attr("d", arc);*/

  this.divs.selectAll("path").data(pie(newValue)).enter().append('path')
    .attr("fill", function(d: any, i: any): any { return colorvalues[i] })
    .attr("d", arc);


  this.divs.selectAll("text").data(pie(newValue)).enter().append("text")
    .attr("transform", function(d:any) {
    })
    .attr("dy", "0.35em")
    .attr("text-anchor", "middle")
    .attr("font-size","17px")
    .text(function(d:any) {
      return newValue[0]+"%";
    }
    );
  }
}
@Component({
  selector: 'my-donutchart',
  directives: [DonutChart],
  template: `
    <div donut-graph
      [data]="values"
      width="150px"
      height="100px">
    </div>
  `
})

export class donutchart {
  values: any;
  @Input('status') status: number;
  constructor() {
    
    
  }

  ngOnInit() {
    this.values = [this.status, 100 - this.status];
   // this.values = [50, 50];
  }
}