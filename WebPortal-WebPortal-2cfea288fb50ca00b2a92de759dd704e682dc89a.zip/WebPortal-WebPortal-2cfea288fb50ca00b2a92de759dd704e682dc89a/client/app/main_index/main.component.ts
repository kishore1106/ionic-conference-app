import {Component, OnInit} from 'angular2/core';
import {RouteConfig, ROUTER_DIRECTIVES} from 'angular2/router';
import {ProjectService} from './../shared/project.service';
import {HeaderComponent} from './../header/header.component';
import {FilterComponent} from './../filter/filter.component';
import {ProjectCardComponent} from './../projectCard/projectCard.component';
import {ProjectComponent} from './../project/project.component';
import {MainProjectDetailsComponent} from './../main_projectDetails/main_projectDetails.component';

@Component({
	selector: 'webportal',
	template:require('./main.html'),
 
	directives: [HeaderComponent, FilterComponent, ProjectCardComponent, ProjectComponent, ROUTER_DIRECTIVES],
	providers: [ProjectService]
})

@RouteConfig([
	// { path: '/projectsssss', name: 'Project', component: FilterComponent},
	// { path: '/projectdetail/:id', name: 'ProjectDetail', component: MainProjectDetailsComponent }
])

export class MainComponent {
	constructor() {
		
	}
}
