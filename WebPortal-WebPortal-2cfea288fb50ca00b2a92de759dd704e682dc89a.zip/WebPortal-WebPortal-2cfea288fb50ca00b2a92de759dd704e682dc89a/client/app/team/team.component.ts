import {Component, OnInit, Input, Output, EventEmitter} from 'angular2/core';
import {Pipe, PipeTransform} from 'angular2/core'; 
import {Router} from 'angular2/router';
import {TeamService} from './../shared/team.service';
import {Team} from './team';

@Pipe({
    name: "searchText"
})

class SearchTextPipe implements PipeTransform {
    transform(section: any, args: string[]) {
        let [searchKey, label] = args;
        if (searchKey == '' || searchKey == undefined) {
            return section;
        }
        return section.filter((section: any) => section[label].indexOf(searchKey) !== -1);
    }
}


@Component({
  selector: 'team-list',
  pipes: [SearchTextPipe],
  template:require('./team.html'),
  styleUrls: ['./styles/css/people.css']
})

export class TeamComponent {
  @Input() teams: Team[];
 
  @Output() selectedTeam = new EventEmitter<String[]>();

 
  toggleSelectState: string = 'none';
  multiselectHeader: string[];
  selectedTeams: string[];

  @Input('collection') collection: any;
  @Input('multiple') multiple: boolean;
  @Input('label') label: string;
  @Input('header') header: string[];
  @Input('mutiselectModel') mutiselectModel: any;

  @Output() selected = new EventEmitter<String[]>();

  ngOnInit() {
    this.multiselectHeader = this.header;
  }

  toggleSelect() {
    if (this.toggleSelectState == 'none') {
      this.toggleSelectState = 'block';
    } else {
      this.toggleSelectState = 'none';
    }
  }

  checkAll() {
    if (this.multiple != true) {
      return;
    }
    this.collection.forEach((t: any) => t.checked = true);
    this.updateMultipleModel();
  }

  unCheckAll() {
    this.collection.forEach((t: any) => t.checked = false);
    this.multiselectHeader = this.header;
    this.updateMultipleModel();
  }

  selectItem(team: any) {
    team.checked = !team.checked;
    this.updateMultipleModel();
  }

  updateMultipleModel() {
    this.mutiselectModel = [];
    this.multiselectHeader = ["Team"];
    for (let team of this.collection) {
    if (team.checked) {
        this.mutiselectModel.push(team);
        this.multiselectHeader = this.mutiselectModel.map((multiselect: any) => multiselect.team_name);
      }
    }
    this.selectedTeams = this.multiselectHeader;
    if (this.selectedTeams[0] == 'Team') {
        this.selectedTeams = [];
    }
  
  this.selectedTeam.emit(this.selectedTeams);
  }

}