import {Project} from './../project/project';

export interface Team {
	team_id: string;
	team_name: string;
	team_lead_name: string;
	projects: Project[];
}
