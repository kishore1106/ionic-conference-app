///<reference path="../node_modules/angular2/typings/browser.d.ts"/>
///<reference path="../typings/tsd.d.ts" />

import 'reflect-metadata';
import { bootstrap } from 'angular2/platform/browser';
import { MainComponent } from './main_index/main.component';
import { HomepageComponent } from './homepage/homepage.component'
import {HTTP_PROVIDERS} from 'angular2/http';
import {ROUTER_PROVIDERS} from 'angular2/router';
import 'rxjs/Rx';
import './styles/css/bootstrap.css';
import './styles/css/header.css';

bootstrap(HomepageComponent, [HTTP_PROVIDERS, ROUTER_PROVIDERS]);
