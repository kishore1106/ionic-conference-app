import {Injectable} from 'angular2/core';
import {Http, Response} from 'angular2/http';
import { TeamList } from './../MockData/teamList';
import {Team} from './../team/team';
import {Observable} from 'rxjs/Observable';


@Injectable()
export class TeamService {


	constructor(private http: Http) { }

	getteam() {
		return this.http.get("./MockData/teamList.json").map(response => <Team[]>response.json())
	}


}
