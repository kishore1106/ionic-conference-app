import {Injectable} from 'angular2/core';
import {Http, Response} from 'angular2/http';
import { PeopleList } from './../MockData/peopleList';
import {People} from './../people/people';
import {Observable} from 'rxjs/Observable';


@Injectable()
export class PeopleService {
   
    
  constructor(private http: Http) { }
      
  getpeople() {    
    return this.http.get("./MockData/peopleList.json").map(response => <People[]>response.json())                                   
  }
 
  
}
