import {Injectable} from 'angular2/core';
import {Http,Response} from 'angular2/http'
import { ProjectList } from './../MockData/projectList';
import {Project} from './../project/project';
import {Observable} from 'rxjs/Observable';


@Injectable()
export class ProjectService {
   
    
  constructor(private http: Http) { }
      
  getProject() {    

    return this.http.get("./MockData/projectList.json")
      .map(response => <Project[]>response.json())
      // .filter(project => project.project_id === pid);                                  
  }
	 
}
