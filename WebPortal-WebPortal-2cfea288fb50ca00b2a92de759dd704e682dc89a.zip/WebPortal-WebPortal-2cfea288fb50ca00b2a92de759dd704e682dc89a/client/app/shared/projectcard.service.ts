import {Injectable} from 'angular2/core';
import {Http, Response} from 'angular2/http';
import {ProjectCardList} from './../MockData/projectCard';
import {ProjectCard} from './../projectCard/projectCard';
import {Observable} from 'rxjs/Observable';


@Injectable()
export class ProjectCardService {


	constructor(private http: Http) { }

	getprojectcard() {
		return this.http.get("./MockData/projectCard.json").map(response => <ProjectCard[]>response.json())
	}


}
