import {Injectable} from 'angular2/core';
import {Http, Response} from 'angular2/http';
//import { SectionList } from './../MockData/sectionList';
import {Section} from './../section/section';
import {Observable} from 'rxjs/Observable';


@Injectable()
export class SectionService {
   
    
  constructor(private http: Http) { }
      
  getsection() {    
	  return this.http.get("./MockData/sectionList.json").map(response => <Section[]>response.json())                                   
  }
 
  
}
