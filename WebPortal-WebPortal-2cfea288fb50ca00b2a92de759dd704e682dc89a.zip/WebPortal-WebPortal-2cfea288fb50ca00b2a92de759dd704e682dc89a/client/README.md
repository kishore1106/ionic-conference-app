# ng2 Seed Project



 Angula2 Seed Project with Webpack and TypeScript
## License
TBD