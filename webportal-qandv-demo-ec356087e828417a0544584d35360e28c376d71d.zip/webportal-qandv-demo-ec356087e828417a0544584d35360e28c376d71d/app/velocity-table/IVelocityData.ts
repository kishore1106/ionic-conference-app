export interface IVelocityData {
	year: string;
	month: string;
	defects: number;
	defectsExtAcsd: number;
	defectsExtCat: number;
}