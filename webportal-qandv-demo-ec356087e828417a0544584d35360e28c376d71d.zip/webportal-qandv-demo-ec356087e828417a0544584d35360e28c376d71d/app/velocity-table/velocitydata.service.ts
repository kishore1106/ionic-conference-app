import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { IVelocity } from './IVelocity';
import { AppSettings } from '../appSettings';
import { DataWrapperService } from '.././common/dataWrapper.service';


@Injectable()
export class VelocityDataService {
    constructor(private http: Http, private dataWrapper: DataWrapperService) { }
    getVelocityDetails(teamID, year) {
        return this.dataWrapper.getData(`${AppSettings.API_URL}teams/${teamID}/velocity?year=${year}`);
    }
    updateVelocityDetails(velocityDetails) {
        return this.dataWrapper.pushData(`${AppSettings.API_URL}teams/${velocityDetails.teamId}/velocity`, velocityDetails.velocityData);
    }
}
