import { Component, OnInit, Input, Output, OnChanges, SimpleChange, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { VelocityDataService } from './velocitydata.service';
import { IVelocity } from './Ivelocity';

@Component({
    // moduleId: module.id,
    selector: 'my-velocity-table',
    templateUrl: '/velocity-table/velocity.table.component.html',


})
export class VelocityTableComponent implements OnInit, OnChanges {
    constructor(private velocityservice: VelocityDataService) { }
    currentTime = new Date();
    year: number = this.currentTime.getFullYear();
    month = this.currentTime.getMonth();
    @Input() editableField: boolean;
    @Input() selectedList: any;
    @Input() yearSelected: any;
    @Output() changedvaluesofvelocity = new EventEmitter();
    // currentTime = new Date();
    // month = this.currentTime.getMonth();
    // year: number = this.currentTime.getFullYear();
    months: any[] = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    editableMonth: string = this.months[this.month];
    velocityDetails: Array<any>;
    velocityYear: any;
    velocityDetail: Array<any>;
    velocityMonth: any;


    ngOnInit() {
        // this.get_details();
    }

    ngOnChanges(changes: { [propKey: string]: SimpleChange }) {
        console.log("selectedId", this.selectedList, this.editableField);
        let selectedlist = changes['selectedList'];
        let year = changes['yearSelected'];
        console.log(selectedlist);

        if (year || selectedlist && (selectedlist.currentValue) && (selectedlist.previousValue != selectedlist.currentValue)) {

            this.get_details();

        }
    }


    get_details() {
        this.velocityDetails = [];
        console.log('***********selected id for table:', this.selectedList);
        if (this.selectedList && this.selectedList.length > 0 && this.selectedList[0].source === "team") {
            this.velocityDetails = [];
            this.selectedList.forEach(velocity => {
                this.velocityDetails = [];
                if (velocity.source === "team") {
                    console.log("velocity", velocity);
                    console.log("currentYear",this.yearSelected);
                    this.velocityservice.getVelocityDetails(velocity._id, this.yearSelected).subscribe((_details: Array<any>) => {
                        let details = _details;
                        // _details=[];
                        console.log("details",details);
                        if (details && this.velocityDetails.length !== this.selectedList.length ) {
                            
                            var currentMonthData = {
                                date: new Date().toISOString(),
                                deliveredOnTimeRelease: 0,
                                cumulativeCycTime: 0

                            }
                            var teamdetail = this.selectedList.find((team) => team._id === details[0].teamId);
                            var velocityMonth = new Date(details[0].velocityData[details[0].velocityData.length - 1].date).getMonth();
                            var velocityYear = new Date(details[0].velocityData[details[0].velocityData.length - 1].date).getFullYear();
                            if (velocityMonth != this.month && velocityYear == this.year) {
                                //      console.log("ebtered");
                                details[0].velocityData.push(currentMonthData);
                                //  console.log("After Pushed",details[0].qualityData);
                            }
                            
                            details[0].teamName = teamdetail.name;
                            // details[0].sectionId = velocity.sectionId;
                            // details[0].source = velocity.source;
                            // details[0]._id = velocity._id;

                            details[0].velocityData.forEach(velocityDataForEachMonth => {
                                this.velocityMonth = new Date(velocityDataForEachMonth.date).getMonth();
                                this.velocityYear = new Date(velocityDataForEachMonth.date).getFullYear();
                                if (this.velocityMonth == this.month && this.velocityYear == this.year) {
                                    velocityDataForEachMonth.isCurrentMonth = true;
                                    velocityDataForEachMonth.editableField = true;
                                }
                                else {
                                    velocityDataForEachMonth.isCurrentMonth = false;
                                    velocityDataForEachMonth.editableField = false;
                                }
                            });


                            this.velocityDetails = [...this.velocityDetails, ...details];
                            console.log(this.velocityDetails);
                             /**remove the duplicate team details */
                             var listofteamsdetails = this.velocityDetails.filter((thing, index, self) =>
                                            self.findIndex((t) =>
                                 { return t.teamId === thing.teamId; }) === index);
                                 console.log('final velocity detail after remval',listofteamsdetails);
                                 
                                 this.velocityDetails = listofteamsdetails;
                            /**remove the duplicate team details */
                        }
                        else {
                            console.log("empty");
                        }
                        // this.selectedList=[];
                    });
                }
                // this.selectedList=[];
            });
            // this.display = true;
        }
    }
    onClickdefects(value, date, teamid, sectionid, divisionid) {
        console.log("velocitydata", this.velocityDetails);
        this.changedvaluesofvelocity.emit(this.velocityDetails);
    }
    onSelectYear(yearId) {
        this.year = yearId;
        this.get_details();
        console.log("year selected", this.year);
    }
  editpermission(edit,index,teamdata) {
        // this.editableField = edit;
        /**change the last month data to un editable */
        teamdata.velocityData[teamdata.velocityData.length -1].editableField = edit;
        console.log('rights:', this.editableField,"index",index,"editablemonthdata",teamdata);

    }
}

