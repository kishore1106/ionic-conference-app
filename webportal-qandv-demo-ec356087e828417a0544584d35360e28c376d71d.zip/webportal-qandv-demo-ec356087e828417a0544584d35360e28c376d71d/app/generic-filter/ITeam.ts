export interface ITeam {
    id: string;
    name: string;
    parentId: string;
    source: string;
}