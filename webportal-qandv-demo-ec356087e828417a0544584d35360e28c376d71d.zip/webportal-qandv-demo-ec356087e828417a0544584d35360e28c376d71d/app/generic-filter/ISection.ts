
export interface ISection {
    _id: string;
    name: string;
    divisionId: string;
    
}