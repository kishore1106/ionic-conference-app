import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import {AppSettings} from '../appSettings';
import {DataWrapperService} from '.././common/dataWrapper.service';

import { IUser } from './IUser';
var jwt_Decode = require('jwt-decode');
@Injectable()
export class GenericFilterService {
    constructor(private http: Http, private dataWrapper:DataWrapperService) { }
	getDetails(cwsId) {

		if (sessionStorage.getItem('accessToken')) {
			var accessToken = sessionStorage.getItem('accessToken')
			var decoded = jwt_Decode(accessToken);//decode the jwt and get the cws id or cat login id;
            console.log('decoded', decoded);
			var Id = decoded['http://schemas.cat.com/identity/claims/catloginid'];
			cwsId="sowmi";//sabibm chennj
			return this.dataWrapper.getData(`${AppSettings.API_URL}users?cwsId=${cwsId}`);
		}
	}
    getDivisions(departmentID) {
        return this.dataWrapper.getData(`${AppSettings.API_URL}department/${departmentID}/divisions`);
    }

    getSections(divisionID: string) {
		return this.dataWrapper.getData(`${AppSettings.API_URL}divisions/${divisionID}/sections`);
	}

    getTeams(sectionID: string) {
		return this.dataWrapper.getData(`${AppSettings.API_URL}sections/${sectionID}/teams`);
	}
}
