import { Component, OnInit } from '@angular/core';
import { QualityTableComponent } from '.././quality-table/quality.table.component';
//import { GenericFilterComponent } from '.././generic-filter/generic.filter.component';
import { MultiSelectComponent } from '.././ng2-multiselect/multi.select.component';
import { SaveComponent } from '.././save/save.component';
import { GraphComponent } from './graph-component/graph.component';
import { ReportDataService } from './reportdata.service';
import {RouterOutlet, RouterLink, RouterLinkWithHref, RouterLinkActive} from '@angular/router';


@Component({
  selector: 'report',
  templateUrl: 'report/report.component.html',
  // directives: [MultiSelectComponent,GraphComponent],
  providers: [ReportDataService]
})
export class ReportComponent implements OnInit {
  constructor(private _reportdataservice: ReportDataService) { }
  report: boolean = true;
  selectedSection: any;
  qualityImprovement: any;
  externalToAcsd: any;
  externalToCat: any;
  onTimeDelivery: any;
  productivityImprovement: any;
  currentTime = new Date();
  year: number = this.currentTime.getFullYear();
  reportDetails: any = {
    sectionId: '',
    sectionName: '',
    Data: [

    ]
  };
  years: any = [
    { id: this.currentTime.getFullYear() },
    { id: this.currentTime.getFullYear() - 1 }


  ];
  months: any = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  fileName: string = 'TES';
  reportDetailsQualityArray: any;
  reportDetailsVelocityArray: any;
  ngOnInit() {
    // this.getDetailsForReport(this.fileName);
  }
  getDetailsForReport(sectionId: string) {
    console.log("inside");
    this._reportdataservice.getReportsForSection(sectionId, this.year).subscribe((qualityReportsBySection: any) => {
      qualityReportsBySection.sectionName = this.selectedSection.name;
      this.reportDetailsQualityArray = qualityReportsBySection;
      console.log("reportDetailsQualityArray",this.reportDetailsQualityArray);
      this.qualityImprovement = this.reportDetailsQualityArray.qualityData[(this.reportDetailsQualityArray.qualityData.length) - 1].qualityImprovementPercentage;
      this.externalToCat = this.reportDetailsQualityArray.aggrExtCat;
      this.externalToAcsd = this.reportDetailsQualityArray.aggrExtAcsd;



    });
    this._reportdataservice.getVelocityDetailsBySectionId(sectionId,this.year).subscribe((velocityData:any) => {
            this.reportDetailsVelocityArray=velocityData;
            this.productivityImprovement=this.reportDetailsVelocityArray.velocityData[(this.reportDetailsVelocityArray.velocityData.length) - 1].productiveImprovement;
            this.onTimeDelivery=this.reportDetailsVelocityArray.velocityData[(this.reportDetailsVelocityArray.velocityData.length) - 1].onTimeDelivery;

    });
    // console.log('this.sectionLevelQualityDetails', this.reportDetails);
    // this.sectionaggregatedvalue = true;
  }
  //this.disableTeamDropdown.emit(this.sectionaggregatedvalue);//to disable team drop drown
  selectedListOutput(selectedSection) {
    this.selectedSection = selectedSection;
    //console.log("emitteddddd at the report", this.selectedSection);
    if (typeof (this.selectedSection) != "undefined") {
      console.log("eeememmiiiiittteeeddddd", this.selectedSection);
      if(this.selectedSection.source === "section")
      {
        this.getDetailsForReport(this.selectedSection._id);
      }
      if(this.selectedSection.source === "division")
      {
        console.log("division report",this.selectedSection._id);
        this.getDetailsForDivisionReport(this.selectedSection._id);
      }
      
      if(this.selectedSection.source === "department"){
        this.getDetailsForDepartmentReport(this.selectedSection._id);
        console.log("department report",this.selectedSection._id);
        // this.getDetailsForDepartmentReport(this.selectedSection._id);
      }
      if(this.selectedSection.source==="team"){
        this.getDetailsForTeamReport(this.selectedSection._id);
        console.log("reports under construction");
      }
    }
  }
  selectedYear(yearId) {

    this.year= yearId;
    this.getDetailsForReport(this.selectedSection._id);
    console.log("*********************year selected**************", this.year);
  }

  getDetailsForDivisionReport(divisionId: string) {
    console.log("inside");
    this._reportdataservice.getReportsForDivision(divisionId, this.year).subscribe((qualityReportsBySection: any) => {
      qualityReportsBySection.divisionName = this.selectedSection.name;
      console.log("division name",qualityReportsBySection.divisionName);
      this.reportDetailsQualityArray = qualityReportsBySection;
      console.log("reportDetailsQualityArray",this.reportDetailsQualityArray);
      
      this.qualityImprovement = this.reportDetailsQualityArray.qualityData[(this.reportDetailsQualityArray.qualityData.length) - 1].qualityImprovementPercentage;
      this.externalToCat = this.reportDetailsQualityArray.aggrExtCat;
      this.externalToAcsd = this.reportDetailsQualityArray.aggrExtAcsd;



    });
    this._reportdataservice.getVelocityDetailsByDivisionId(divisionId,this.year).subscribe((velocityData:any) => {
            this.reportDetailsVelocityArray=velocityData;
            this.productivityImprovement=this.reportDetailsVelocityArray.velocityData[(this.reportDetailsVelocityArray.velocityData.length) - 1].productiveImprovement;
            this.onTimeDelivery=this.reportDetailsVelocityArray.velocityData[(this.reportDetailsVelocityArray.velocityData.length) - 1].onTimeDelivery;

    });
    // console.log('this.sectionLevelQualityDetails', this.reportDetails);
    // this.sectionaggregatedvalue = true;
  }

  getDetailsForDepartmentReport(departmentId: string) {
    console.log("inside");
    this._reportdataservice.getQualityReportsForDepartment(departmentId, this.year).subscribe((qualityReportsByDepartment: any) => {
      qualityReportsByDepartment.departmentName = this.selectedSection.name;
      this.reportDetailsQualityArray = qualityReportsByDepartment;
      this.qualityImprovement = this.reportDetailsQualityArray.qualityData[(this.reportDetailsQualityArray.qualityData.length) - 1].qualityImprovementPercentage;
      this.externalToCat = this.reportDetailsQualityArray.aggrExtCat;
      this.externalToAcsd = this.reportDetailsQualityArray.aggrExtAcsd;



    });
    this._reportdataservice.getVelocityDetailsForDepartment(departmentId,this.year).subscribe((velocityReportsByDepartment:any) => {
            this.reportDetailsVelocityArray=velocityReportsByDepartment;
            this.productivityImprovement=this.reportDetailsVelocityArray.velocityData[(this.reportDetailsVelocityArray.velocityData.length) - 1].productiveImprovement;
            this.onTimeDelivery=this.reportDetailsVelocityArray.velocityData[(this.reportDetailsVelocityArray.velocityData.length) - 1].onTimeDelivery;

    });
    // console.log('this.sectionLevelQualityDetails', this.reportDetails);
    // this.sectionaggregatedvalue = true;
  }
  getDetailsForTeamReport(teamId:string){
    console.log("inside");
    this._reportdataservice.getQualityDetailsForTeam(teamId, this.year).subscribe((qualityReportsByTeam: any) => {
      qualityReportsByTeam.teamName = this.selectedSection.name;
      this.reportDetailsQualityArray = qualityReportsByTeam;
      this.qualityImprovement = this.reportDetailsQualityArray.qualityData[(this.reportDetailsQualityArray.qualityData.length) - 1].qualityImprovementPercentage;
      this.externalToCat = this.reportDetailsQualityArray.aggrExtCat;
      this.externalToAcsd = this.reportDetailsQualityArray.aggrExtAcsd;



    });
    this._reportdataservice.getVelocityDetailsForTeam(teamId,this.year).subscribe((velocityReportsByTeam:any) => {
            this.reportDetailsVelocityArray=velocityReportsByTeam;
            this.productivityImprovement=this.reportDetailsVelocityArray.velocityData[(this.reportDetailsVelocityArray.velocityData.length) - 1].productiveImprovement;
            this.onTimeDelivery=this.reportDetailsVelocityArray.velocityData[(this.reportDetailsVelocityArray.velocityData.length) - 1].onTimeDelivery;

    });
  }
}