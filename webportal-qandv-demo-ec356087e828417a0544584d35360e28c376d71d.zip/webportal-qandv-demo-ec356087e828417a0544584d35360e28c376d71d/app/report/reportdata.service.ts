import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { AppSettings } from '../appSettings';
import {DataWrapperService} from '.././common/dataWrapper.service';

@Injectable()
export class ReportDataService {
    // filename:string="tes.division";
    constructor(private http: Http, private dataWrapper: DataWrapperService) { }
    getQualityDetailsBySectionId(sectionID) {
        return this.dataWrapper.getData(`${AppSettings.API_URL}sections/${sectionID}/quality`);
    }
    getVelocityDetailsBySectionId(sectionID, year) {
        return this.dataWrapper.getData(`${AppSettings.API_URL}sections/${sectionID}/velocity/reports?year=${year}`);
    }
    getWeigthageForTeam(teamID, year) {
        return this.dataWrapper.getData(`${AppSettings.API_URL}velocityWeightage/${teamID}?year=${year}`);
    }
    getReportsForSection(sectionID, year) {
        return this.dataWrapper.getData(`${AppSettings.API_URL}sections/${sectionID}/quality/reports?year=${year}`);
    }
    getReportsForDivision(divisionID, year) {
        return this.dataWrapper.getData(`${AppSettings.API_URL}divisions/${divisionID}/quality/reports?year=${year}`);
    }
    getVelocityDetailsByDivisionId(divisionID, year) {
        return this.dataWrapper.getData(`${AppSettings.API_URL}divisions/${divisionID}/velocity/reports?year=${year}`);
    }
    getQualityReportsForDepartment(departmentID, year) {
        return this.dataWrapper.getData(`${AppSettings.API_URL}departments/${departmentID}/quality/reports?year=${year}`);
    }
    getVelocityDetailsForDepartment(departmentID, year) {
        return this.dataWrapper.getData(`${AppSettings.API_URL}departments/${departmentID}/velocity/reports?year=${year}`);
    }
    getQualityDetailsForTeam(teamID, year) {
        return this.dataWrapper.getData(`${AppSettings.API_URL}teams/${teamID}/quality/reports?year=${year}`);
    }
    getVelocityDetailsForTeam(teamID, year) {
        return this.dataWrapper.getData(`${AppSettings.API_URL}teams/${teamID}/velocity/reports?year=${year}`);
    }
}