import { Component, OnInit } from '@angular/core';

@Component({
    // moduleId: module.id,
    selector: 'user',
    templateUrl: 'layout/header/user/user.component.html'
})
export class UserComponent implements OnInit {
    constructor() { }

    ngOnInit() { }

}