import { Component, OnInit } from '@angular/core';

@Component({
    // moduleId: module.id,
    selector: 'logo',
    templateUrl: 'layout/header/logo/logo.component.html'
   })
export class LogoComponent implements OnInit {
    constructor() { }

    ngOnInit() { }

}