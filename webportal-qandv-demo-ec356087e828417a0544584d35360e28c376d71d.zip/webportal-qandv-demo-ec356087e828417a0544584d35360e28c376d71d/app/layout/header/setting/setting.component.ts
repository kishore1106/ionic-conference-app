import { Component, OnInit } from '@angular/core';

@Component({
    // moduleId: module.id,
    selector: 'setting',
    templateUrl: 'layout/header/setting/setting.component.html'
})
export class SettingComponent implements OnInit {
    constructor() { }

    ngOnInit() { }

}