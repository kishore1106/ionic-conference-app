import { Component, OnInit } from '@angular/core';

@Component({
    // moduleId: module.id,
    selector: 'search',
    templateUrl: 'layout/header/search/search.component.html',


})
export class SearchComponent implements OnInit {
    constructor() { }

    ngOnInit() { }

}