import { Component, OnInit, Input ,OnChanges} from '@angular/core';

@Component({
    selector: 'wpHeader',
    templateUrl: 'layout/header/header.component.html',
    styleUrls: ['layout/header/header.style.css']
})
export class HeaderComponent implements OnInit {
    @Input() userDetailsFirstName: any;
    @Input() userDetailsLastName: any;
    constructor() { }
    
    
    ngOnInit() { }
    onClickLogOut() {
        if (sessionStorage.getItem('accessToken')) {
            console.log("logout", sessionStorage.getItem('accessToken'));
            sessionStorage.removeItem('accessToken');
            event.preventDefault();
            window.location.href="https://loginq.cat.com/cgi-bin/logout";//https://loginq.cat.com/cgi-bin/logout
        }
    }

}