import { Component, OnInit } from '@angular/core';

@Component({
    // moduleId: module.id,
    selector: 'my-footer',
    templateUrl: 'layout/footer/footer.component.html',
    styleUrls:['layout/footer/footer.component.css']
})
export class FooterComponent implements OnInit {
    constructor() { }

    ngOnInit() { }

}