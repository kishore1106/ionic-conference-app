import { Injectable, } from '@angular/core';
import { Http, Response } from '@angular/http';
import {IUser}from './IUser';
import { Subject }    from 'rxjs/Subject'


@Injectable()
export class UserDataService {

    constructor(private http: Http) { }

    userDetail= new Subject<any>();
    userDetailEmitter$ = this.userDetail.asObservable();

    sendUser(user:any){
        this.userDetail.next(user);
    }
    setUser(user:any){
        this.userDetail = user;
    }

    // getUserDetails(cwsId:string) {
    //     return this.http.get("http://localhost:8001/user?cwsId="+cwsId)
    //         .map((res: Response) => <Array<any>>res.json());
    // }
}