import { Component, OnInit} from '@angular/core';

import { GenericFilterService } from '../.././generic-filter/generic.filter.service';
import { HeaderComponent } from '../header/header.component';
import { FooterComponent } from '.././footer/footer.component';
import { SaveComponent   }from '../../save/save.component';
// import{UserDataService}from './shell.service';
import { SpinnerComponent } from '../../spinner/spinner.component';
import { Router } from '@angular/router';
import { QualityComponent } from '../../quality/quality.component';
import { UserDataService } from './shell.service';
import { Subscription }   from 'rxjs/Subscription';


import { LoginService } from '../../login/loginservice.service';
import { AuthService } from '../../login/auth.service';
var jwt_Decode = require('jwt-decode');
@Component({
    // moduleId: module.id,
    selector: 'shell',
    templateUrl: 'layout/shell/shell.component.html',
  providers:[UserDataService]

})

export class ShellComponent implements OnInit{
    userDetails: Array<any>;
    userDetailsFirstName: any;
    userSections: any;
    userDetailsLastName: any;
    cwsId = "";
    quality:any;
    velocity:any;
    // cwsId: any = "chennj";
    isAdmin: boolean = true;/// get this value from the userDetails
    isAuth: boolean = false;
    isRequesting: boolean;
    user:any;
    enableReports:any;
    subscription: Subscription;
    // constructor(private _loginservice: LoginService, private _authorizationService: AuthService) { }
 constructor(private _loginservice: LoginService, private _authorizationService: AuthService, private _genericfilterservice: GenericFilterService,private _userDataService:UserDataService) { }
    ngOnInit() {
       
        this._loginservice.isAccessTokenAvailable();
        this.isAuth = this._authorizationService.isLoggedIn;
        console.log('isAuth', this.isAuth);
         this.getDetails();
    }
    getDetails() {
        if(sessionStorage.getItem('accessToken')){
            var accessToken = sessionStorage.getItem('accessToken')
            console.log("accessToken",accessToken);
            // this._loginservice.requestUserInfo(accessToken).subscribe((user) => console.log("******userInfo*******",user));
			var decoded = jwt_Decode(accessToken);//decode the jwt and get the cws id or cat login id;
            console.log('decoded', decoded);
			var Id = decoded['http://schemas.cat.com/identity/claims/catloginid'];
            // var userInfo=decoded["https://fedloginqa.cat.com/idp/userinfo.openid"];
            // console.log("uuusserrr",userInfo);
        this._genericfilterservice.getDetails(this.cwsId).subscribe((_users: any) => {
            let user: any = _users;
            console.log("user at shell", user);
            if (user) {
                this.userDetailsFirstName = user.firstName;
                this.userDetailsLastName = user.lastName;
                this.isAdmin=user.isAdmin;
                this.quality=true;
                this.velocity=true;
                this.enableReports=true;
            }
            else if(user==null){
                this.userDetailsFirstName=Id;
                this.userDetailsLastName=Id;
                this.quality=false;
                this.velocity=false;
                this.enableReports=true;
                this.isAdmin=false;
            }
        })
    }
}
//     ngOnDestroy(){
//     this.subscription.unsubscribe();
// }
    onActivate(role){
        // this.role= role;
        console.log('role at shell',role);
        console.log('test role',role.user);
        //console.log( this.myChildQualityComponent.user);
        
       
    }
    getuserdetails(user)
{
    console.log("user at shell",user);
    
}
}
