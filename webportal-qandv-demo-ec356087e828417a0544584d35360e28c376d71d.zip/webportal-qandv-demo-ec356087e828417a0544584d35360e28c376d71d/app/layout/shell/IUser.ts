export interface IUser {
	firstName: string;
	lastName: string;
	teams:any[];
	sections:any[];
	divisions:any[];
}