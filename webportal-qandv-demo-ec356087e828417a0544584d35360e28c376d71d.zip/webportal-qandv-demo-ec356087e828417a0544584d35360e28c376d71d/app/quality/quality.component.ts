import { Component, OnInit, Input, Output,EventEmitter } from '@angular/core';

// import { MultiSelectComponent } from '.././ng2-multiselect/multi.select.component';
// import { QualityTableComponent } from '.././quality-table/quality.table.component';
// import { SaveComponent } from '.././save/save.component';
 import { IList } from '.././generic-filter/generic-selector/IList';
// import { IMultiSelectOption } from './mulity';
 import { UserDataService } from '../layout/shell/shell.service';
 import { Subscription }   from 'rxjs/Subscription';
@Component({
  // moduleId: module.id,
  selector: 'quality',
  templateUrl: '/quality/quality.component.html',
    providers:[UserDataService]
  //directives: [MultiSelectComponent, QualityTableComponent, SaveComponent]
})
export class QualityComponent implements OnInit {
  constructor(private _userDataService:UserDataService) { }
  currentTime=new Date();
  year:any=this.currentTime.getFullYear();
  editablefield: boolean=true;
  selectedList: Array<IList>=[];
  selectedListOfsections=[];
  selectedListOfdivisions=[];
  changedQualityArray: any[];
 showAggregation:any;
  disableTeamdropdown:boolean;// to disable team dropdown while checking section level aggregation checkbox.
  user:any;
  ngOnInit() { 
    // localStorage.getItem('accessToken')
  }

  selectList(list: Array<IList>) {
    // console.log('table details', list);
    this.selectedList = list.map(item => item);
    console.log('req-id', this.selectedList);
  }
  changedvaluesofqualitytable(changedQaulityDetails) {
    this.changedQualityArray = changedQaulityDetails;
    // console.log('changed deta at report:',this.changedQualityArray);

  }
  editpermission(edit) {
    this.editablefield = edit;
    console.log('rights:', this.editablefield);

  }
  disableDropdown(booleanValue){

    console.log("booleanValue",booleanValue);
    this.disableTeamdropdown=booleanValue;
  }

  selectedYear(year){
 
    this.year=year;
       console.log("yeeeeaaaarrrrrrr",year);
  }

  disableEdit(edit){
    this.editablefield=edit;
    console.log("ediiittttiiiiinnngggg",this.editablefield);
  }
  /*get user role */
  getBooleanValuesForAggregation(aggregation){
    this.showAggregation= aggregation;
    console.log("aggregation at quality",this.showAggregation);
    

  }
  selectedlistofsections(listOfSections){
    this.selectedListOfsections = listOfSections;
    console.log("this.selectedListOfsections",this.selectedListOfsections);
    
  }
  selectedlistofdivisions(listofDivisions){
    this.selectedListOfdivisions=listofDivisions;
    console.log("this.selectedListOfdivisions",this.selectedListOfdivisions);
  }
   subscription: Subscription;
   @Output() userdetail: EventEmitter<any> = new EventEmitter<any>();

  getuserdetail(userdetail){
    console.log("userdetail at quality",userdetail);
    
   //this.userdetail.emit(userdetail);
    // this.user= userdetail;
    // this._userDataService.sendUser(this.user)
  }

}