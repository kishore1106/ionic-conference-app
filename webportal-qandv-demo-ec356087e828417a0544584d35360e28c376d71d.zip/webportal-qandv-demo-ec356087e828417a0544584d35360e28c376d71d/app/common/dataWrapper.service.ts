import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';

@Injectable()
export class DataWrapperService {
    constructor(private http: Http) { }
    getData(requestURL) {
        return this.http.get(requestURL)
            .map((res: Response) => <Array<any>>res.json());
    }
    pushData(requestURL, data) {
        let body = JSON.stringify(data);
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        return this.http.post(requestURL, body, options)
            .map((res: Response) => <Array<any>>res.json());
    }
}