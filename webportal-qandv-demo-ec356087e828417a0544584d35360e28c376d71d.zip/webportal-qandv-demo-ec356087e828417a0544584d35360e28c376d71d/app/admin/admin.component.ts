import { Component, OnInit, Input, Output, SimpleChange, EventEmitter } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { AdminService } from './admin.service';

import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { RotatingPlaneComponent } from 'ng2-spin-kit/app/spinner/rotating-plane.component'

@Component({
    // moduleId: module.id,
    selector: 'admin',
    templateUrl: '/admin/admin.component.html',

})

export class AdminComponent implements OnInit {
    /** properties to hold lists */
    departmentList: any = [];
    divisionList: any = [];
    sectionList: any = [];
    teamList: any = [];
    roleList: any = ['Team Member', 'Team Lead', 'Section Coordinator', 'Supervisor',
        'Division Coordinator', 'Division Manager', 'Department Manager'];

    /**properties to store selected value */
    selectedRole: any = "";
    selectedDepartment: any;
    selectedDivision: any;
    selectedSection: any;
    selectedTeam: any;
    /**properties to store weitage values */
    divisionWeightage: any;
    sectionWeightage: any;
    teamWeightage: any;

    /**boolean value to show add new user ui */
    createNewUser: boolean;
    changeAcutalAndGoal: boolean;
    moveTeam: boolean;
    moveSection: boolean;
    movingNewTeam: any;
    changeWeightage: boolean;

    // @Input() label: String;
    // status: boolean;
    // @Output() selectedListOutput: EventEmitter<any> = new EventEmitter<any>();
    // items: Array<any>;
    selectedList: any;
    disable: boolean = true;
    // select: boolean;

    newUserDetails = {
        firstName: "",
        lastName: "",
        cwsId: "",
        role: "",
        accessTo: "",
        isAdmin: false
    };
    user = {};
    disableSaveButton: boolean = false;
    isRequesting: boolean;
    enableSpinner: boolean = false;
    /**current month and year */
    currentTime: any = new Date();
    currentMonth: any = this.currentTime.getMonth();
    currentYear: any = this.currentTime.getFullYear();
    movingTeam: any;
    movingSection: any;
    teamGoal: number;
    teamActual: number;
    fromSection: any;
    teamCyc:number;
    cycTime:boolean;
    cteamList:any;
    selectedTeamForChange:any;
    fromDivision: any;
    previousMonth: any;
    previousMonthDivisionWeightage: any;
    currentMonthDivisionWeightage: any;
    previousMonthSectionWeightage: any;
    currentMonthSectionWeightage: any;
    previousMonthTeamWeightage: any;
    currentMonthTeamWeightage: any;
    /** */
    constructor(private _adminService: AdminService, private _toaster: ToastsManager) {

    }

    /** ngoninit code starts here */
    ngOnInit() {
        this.isRequesting = true;
        // this._adminService.getAllRoles().subscribe((roles) => {
        //     let rolelist = roles;
        //     if (rolelist) {
        //         this.roleList = rolelist;
        //         console.log(this.roleList);

        //     }
        // });
        this._adminService.getAllTeams().subscribe((teams) => {
            // this.isRequesting = true;
            let teamlist = teams;
            if (teamlist) {
                this.teamList = teamlist;
                this.cteamList=teamlist;
                console.log(this.teamList);
                // this.isRequesting = false;
            }
        });

        this._adminService.getAllSections().subscribe((sections) => {
            this.isRequesting = true;
            let sectionlist = sections;
            if (sectionlist) {
                this.sectionList = sectionlist;
                console.log(this.sectionList);
                this.isRequesting = false;
            }
        });
        this._adminService.getAllDivisions().subscribe((division) => {
            this.isRequesting = true;
            let divisionlist = division;
            if (divisionlist) {
                this.divisionList = divisionlist;
                console.log(this.divisionList);
                this.isRequesting = false;
            }
        });
        this._adminService.getAllDepartment().subscribe((department) => {
            this.isRequesting = true;
            let departmentlist = department;
            if (departmentlist) {
                this.departmentList = departmentlist;
                console.log(this.departmentList);
                this.isRequesting = false;
            }
        });
        this.isRequesting = false;
    }
    /** ngoninit code ends here */

    /** loading spinner code starts here */
    loading() {
        this.isRequesting = true;
    }
    /** loading spinner code ends here */



    ngOnChanges(changes: { [propertyName: string]: SimpleChange }) {
        if ((this.divisionWeightage) != null) {
            console.log("lists", this.divisionWeightage);
            // this.selectedList = this.lists[0];
            //      this.items=this.lists; 
            // console.log("this.items", this.items);
            // setTimeout(() => { this.selectedListOutput.emit(this.selectedList); });
        }
    }

    addnewuser() {
        this.createNewUser = true;
        this.changeWeightage = false;
        this.moveTeam = false;
        this.moveSection = false;
        this.cycTime=false;
        this.changeAcutalAndGoal = false;
        
    }
    onclickCycTime(){
        this.cycTime=true;
        this.changeAcutalAndGoal = false;
        this.moveSection = false;
        this.changeWeightage = false;
        this.createNewUser = false;
        this.moveTeam = false;
        this.disableSaveButton=true;
    }
    onclickactualgoal() {
            this.cycTime=true;
        this.changeAcutalAndGoal = true;
        this.moveSection = false;
        this.changeWeightage = false;
        this.createNewUser = false;
        this.moveTeam = false;
        this.disableSaveButton=true;
    }

    changeweightage() {
            this.cycTime=false;
        this.changeWeightage = true;
        this.moveSection = false;
        this.createNewUser = false;
        this.moveTeam = false;
        this.changeAcutalAndGoal = false;
    }
    /* Moving the Team */
    movingATeam() {
        this.cycTime=false;
        this.moveTeam = true;
        this.moveSection = true;
        this.createNewUser = false;
        this.changeWeightage = false;
        this.changeAcutalAndGoal = false;
        this.disableSaveButton=true;
    }
    movingASection() {
        this.cycTime=false;
        this.moveTeam = false;
        this.moveSection = true;
        this.createNewUser = false;
        this.changeWeightage = false;
        this.changeAcutalAndGoal = false;
        this.disableSaveButton=true;
    }
    onMovingSection(section) {
        this.movingSection = section;
        console.log("value", section);
        this.isRequesting = true;
        this._adminService.getAllDivisions().subscribe((divisions) => {
            this.isRequesting = true;
            let divisionlist = divisions;
            if (divisionlist && typeof (this.movingSection) != "undefined") {
                this.fromDivision = divisionlist.filter((divisions) => divisions._id === this.movingSection.divisionId);
                console.log("*********division*************", this.divisionList);
                this.isRequesting = false;
            }
        });
    }
    onMovingFromDivision(fromDivision) {

    }
    onMovingToDivision(toDivision) {
        console.log(toDivision);
        if (toDivision) {
            this.movingSection.divisionId = toDivision._id;
            console.log("to", this.movingSection);
        }

    }
    /*moving the team */
    onMovingTeam(team) {
        this.movingTeam = team;
        this.isRequesting = true;
        this._adminService.getAllSections().subscribe((sections) => {
            this.isRequesting = true;
            let sectionlist = sections;
            if (sectionlist && typeof (this.movingTeam) != "undefined") {
                this.fromSection = sectionlist.filter((sections) => sections._id === this.movingTeam.sectionId);
                console.log("*********section*************", this.sectionList);
                this.isRequesting = false;
            }
        });
        console.log("value", team);
    }
    onMovingFromSection(fromSection) {
        console.log("from", fromSection);
    }
    onMovingToSection(toSection) {
        console.log(toSection);
        if (toSection) {
            this.movingTeam.sectionId = toSection._id;
            console.log("to", this.movingTeam);
        }

    }
    onSelectRole() {
        console.log("selected role", this.selectedRole);
        this.newUserDetails.role = this.selectedRole;
    }
    onSelectDepartment() {
        if (this.selectedRole = 'Department Manager') {
            this.newUserDetails.accessTo = this.selectedDepartment._id;
            console.log("selected division", this.selectedDepartment);
        }
        else {
            console.log("all department are listed", this.departmentList);
        }
    }
    onSaveTeam() {
        this._adminService.moveTeam(this.movingTeam).subscribe((teamDetails: Array<any>) => {
            if (teamDetails) {
                console.log("teamDetails", teamDetails);
            }
        });

    }
    onSaveSection() {
        this._adminService.moveSection(this.movingSection).subscribe((sectionDetails: Array<any>) => {
            if (sectionDetails) {
                console.log("teamDetails", sectionDetails);
            }
        });

    }

    onSelectDivision() {
        if (this.selectedRole == 'Division Coordinator' || this.selectedRole == 'Division Manager') {
            this.newUserDetails.accessTo = this.selectedDivision._id;
            console.log("selected division", this.selectedDivision._id);

        }

        if (this.changeWeightage) {
            /**code to get weightage */
            console.log("selectedDivision", this.selectedDivision);
            this._adminService.getWeigtagesByID(this.selectedDivision._id).subscribe((weightage) => {
                this.isRequesting = true;
                let divisionWeightage = weightage;
                if (divisionWeightage) {
                    this.divisionWeightage = divisionWeightage;
                    console.log("this.divisionWeightage", this.divisionWeightage);
                    // this.sectionWeightage.find((monthweightage)=>{ var month =new Date(monthweightage.date);
                    //      month.getMonth === this.currentMonth;})
                    this.divisionWeightage[this.currentMonth];
                    console.log('current month data', this.divisionWeightage[this.currentMonth]);
                    //console.log('weightage', this.sectionWeightage.weightage);

                    //var month=this.previousMonth.getFullYear();
                    this.previousMonth = this.divisionWeightage[this.currentMonth - 1].date
                    var month = new Date(this.previousMonth);//
                    console.log(month);

                    this.previousMonthDivisionWeightage = this.divisionWeightage[this.currentMonth].weightage;
                    this.currentMonthDivisionWeightage = this.previousMonthDivisionWeightage;
                    // this.divisionWeightage.forEach((monthdata) => {
                    //     var date = new Date(monthdata.date);
                    //     var month = date.getMonth();
                    //     if (month >= this.currentMonth) {
                    //         monthdata.weightage = this.currentMonthDivisionWeightage
                    //     }
                    // });
                    this.isRequesting = false;
                }
            });
            /**code ends here */
        }

    }

    onSelectSection() {
        if (this.selectedRole == 'Section Coordinator' || this.selectedRole == 'Supervisor') {
            this.newUserDetails.accessTo = this.selectedSection._id;
            console.log("selected sections", this.selectedSection);
        }
        else {
            console.log("all sections are listed", this.sectionList);
            if (this.changeWeightage) {
                /**code to get weightage */
                this._adminService.getWeigtagesByID(this.selectedSection._id).subscribe((weightage) => {
                    this.isRequesting = true;
                    let sectionWeightage = weightage;
                    if (sectionWeightage) {
                        this.sectionWeightage = sectionWeightage;
                        console.log("this.sectionWeightage", this.sectionWeightage);
                        // this.sectionWeightage.find((monthweightage)=>{ var month =new Date(monthweightage.date);
                        //      month.getMonth === this.currentMonth;})
                        this.sectionWeightage[this.currentMonth];
                        console.log('current month data', this.sectionWeightage[this.currentMonth]);
                        //console.log('weightage', this.sectionWeightage.weightage);

                        //var month=this.previousMonth.getFullYear();
                        this.previousMonth = this.sectionWeightage[this.currentMonth - 1].date
                        var month = new Date(this.previousMonth);//
                        console.log(month);

                        this.previousMonthSectionWeightage = this.sectionWeightage[this.currentMonth].weightage;
                        this.currentMonthSectionWeightage = this.previousMonthSectionWeightage;
                        this.sectionWeightage.forEach((monthdata) => {
                            var date = new Date(monthdata.date);
                            var month = date.getMonth();
                            if (month >= this.currentMonth) {
                                monthdata.weightage = this.currentMonthSectionWeightage
                            }
                        });
                        this.isRequesting = false;
                    }
                });
                /**code ends here */
            }
        }
    }
    onSelectCTeam(){
        console.log(this.selectedTeamForChange);
    }
    onSelectTeam() {
        this.newUserDetails.accessTo = this.selectedTeam._id;
        console.log("selected team", this.selectedTeam);
        //this.teamWeightage = this.selectedDivision.weightage;
        if (this.changeAcutalAndGoal) {
            this.disableSaveButton=false;
        }

        if (this.changeWeightage) {
            /**code to get weightage */
            this._adminService.getWeigtagesByID(this.selectedTeam._id).subscribe((weightage) => {
                this.isRequesting = true;
                let teamWeightage = weightage;
                if (teamWeightage) {
                    this.teamWeightage = teamWeightage;
                    console.log("this.sectionWeightage", this.teamWeightage);
                    // this.sectionWeightage.find((monthweightage)=>{ var month =new Date(monthweightage.date);
                    //      month.getMonth === this.currentMonth;})
                    this.teamWeightage[this.currentMonth];
                    console.log('current month data', this.teamWeightage[this.currentMonth]);
                    //console.log('weightage', this.sectionWeightage.weightage);

                    //var month=this.previousMonth.getFullYear();
                    this.previousMonth = this.teamWeightage[this.currentMonth - 1].date
                    var month = new Date(this.previousMonth);//
                    console.log(month);

                    this.previousMonthTeamWeightage = this.teamWeightage[this.currentMonth].weightage;
                    this.currentMonthTeamWeightage = this.previousMonthTeamWeightage;
                    this.teamWeightage.forEach((monthdata) => {
                        var date = new Date(monthdata.date);
                        var month = date.getMonth();
                        if (month >= this.currentMonth) {
                            monthdata.weightage = this.currentMonthTeamWeightage
                        }
                    });
                    this.isRequesting = false;
                }
            });
            /**code ends here */
        }
        /**code to get changeAcutalAndGoal */
        if (this.changeAcutalAndGoal) {
            // this._adminService.getWeigtagesByID(this.selectedTeam._id).subscribe((weightage) => {
            //     this.isRequesting = true;
            //     let teamWeightage = weightage;
            //     if (teamWeightage) {
            //         this.teamWeightage = teamWeightage;
            //         console.log('weightage', this.teamWeightage.weightage);
            //         this.previousMonth = this.teamWeightage.date
            //         //var month=this.previousMonth.getFullYear();
            //         var month = new Date(this.previousMonth);//
            //         console.log(month);

            //         this.previousMonthTeamWeightage = this.teamWeightage.weightage;
            //         this.currentMonthTeamWeightage = this.previousMonthTeamWeightage;
            //         this.isRequesting = false;
            //     }
            // });
        } /**code ends here */

    }
    /** save new user method code starts here */
    saveUser() {
        if ((this.newUserDetails.firstName && this.newUserDetails.cwsId && this.newUserDetails.role && this.newUserDetails.accessTo) != "") {
            this.disableSaveButton == false;
            this._adminService.addNewUser(this.newUserDetails).subscribe((_user) => {
                this.isRequesting = true;
                let user = _user;
                if (user) {
                    this.user = user;
                    console.log("saved successfully", this.user);
                    this._toaster.success('New User has been Saved!', 'Success!');
                    this.isRequesting = false;
                }
                else {
                    console.log("data is still fetch ");
                }
            });
            if (this.user != null) {
                this.newUserDetails = {
                    firstName: "",
                    lastName: "",
                    cwsId: "",
                    role: "",
                    accessTo: "",
                    isAdmin: false
                }
            }
        }
        else {
            this._toaster.success('Your Changes has been Saved!', 'Success!');
            this.disableSaveButton = true;
            console.log("no entry");
        }
    }
    /** save new user method code ends here */

    onSubmit() {
        console.log("saved successfully");
        this._toaster.success('Your Changes has been Saved!', 'Success!');
        console.log("weightage", this.divisionWeightage, this.sectionWeightage, this.teamWeightage);
    }
    onselecfromdepartment() {
        var fromdepartment = "";
        fromdepartment = this.selectedDepartment;
        this._adminService.getAllDivisionsByDepartmentID(fromdepartment).subscribe((division) => {
            let divisionlist = division;
            if (divisionlist) {

                this.divisionList = divisionlist;
                console.log(this.divisionList);
            }
        });
    }
    onselecfromdivision() {
        var fromdivision = "";
        fromdivision = this.selectedDepartment;
        this._adminService.getAllDivisionsByDepartmentID(fromdivision).subscribe((division) => {
            let divisionlist = division;
            if (divisionlist) {
                this.divisionList = divisionlist;
                console.log(this.divisionList);
            }
        });
    }
    onselecfromsection() {
        var fromsection = "";
        fromsection = this.selectedDepartment;
        this._adminService.getAllDivisionsByDepartmentID(fromsection).subscribe((division) => {
            let divisionlist = division;
            if (divisionlist) {
                this.divisionList = divisionlist;
                console.log(this.divisionList);
            }
        });
    }
    onselecfromteam() {
        var fromteam = "";
        fromteam = this.selectedDepartment;
    }
    onSaveActualAndGoal() {

        if (this.selectedTeam) {
            // actualAndGoal.teamId=this.selectedTeam._id;
             this.disableSaveButton=false;
            this._adminService.updateActualAndGoal(this.selectedTeam._id, { "actual": this.teamActual, "goal": this.teamGoal }).subscribe((result) => {
                console.log(result);
            });


        }

    }
    onSaveCycleTime(){
                if (this.selectedTeamForChange) {
            // actualAndGoal.teamId=this.selectedTeam._id;

            this._adminService.updateCycleTime(this.selectedTeamForChange._id, { "cycleTime": this.teamCyc}).subscribe((result) => {
                console.log(result);
            });


        }
    }
    /** testfunction  code starts here */
    onclickSubmitForWeightage() {
        if (this.currentMonthDivisionWeightage != undefined && this.currentMonthDivisionWeightage != "") {
            this.divisionWeightage.forEach((monthdata) => {
                var date = new Date(monthdata.date);
                var month = date.getMonth();
                if (month >= this.currentMonth) {
                    monthdata.weightage = this.currentMonthDivisionWeightage;
                    this._adminService.postNewDivisionWeightagedetils(monthdata).subscribe((result) => {
                        let updatedvalue = result;
                        if (updatedvalue)
                            console.log("successfully updated", updatedvalue);

                    });
                }
            });
            console.log("updated section weightage", this.sectionWeightage);
        }
        if (this.currentMonthSectionWeightage != undefined && this.currentMonthSectionWeightage != "") {
            this.sectionWeightage.forEach((monthdata) => {
                var date = new Date(monthdata.date);
                var month = date.getMonth();
                if (month >= this.currentMonth) {
                    monthdata.weightage = this.currentMonthSectionWeightage;
                    this._adminService.postNewDivisionWeightagedetils(monthdata).subscribe((result) => {
                        let updatedvalue = result;
                        if (updatedvalue)
                            console.log("successfully updated", updatedvalue);

                    });
                }
            });
            console.log("updated section weightage", this.sectionWeightage);

        }
        if (this.currentMonthTeamWeightage != undefined && this.currentMonthTeamWeightage != "") {
            this.teamWeightage.forEach((monthdata) => {
                var date = new Date(monthdata.date);
                var month = date.getMonth();
                if (month >= this.currentMonth) {
                    monthdata.weightage = this.currentMonthTeamWeightage;
                    this._adminService.postNewDivisionWeightagedetils(monthdata).subscribe((result) => {
                        let updatedvalue = result;
                        if (updatedvalue)
                            console.log("successfully updated", updatedvalue);

                    });
                }
            });
            console.log("updated section weightage", this.sectionWeightage);

        }

        this._toaster.success('Your Changes has been Saved!', 'Success!');
    }
    /** testfunction  code ends here */


    /**  method to check whether the month is currrent month code starts here */

    checkForAvailablityOfCurrentMonthData(weightagedetails: any, weightagevalue: number) {

        var lastMonthInWeightagedetails = weightagedetails.date
        var date = new Date(lastMonthInWeightagedetails);
        var month = date.getMonth();
        var year = date.getFullYear();

        if (this.currentMonth != month && this.currentYear === year) {
            weightagedetails._id = "";
            weightagedetails.source = weightagedetails.source;
            weightagedetails.weightage = weightagevalue;
            weightagedetails.date = this.currentTime.toISOString();
            console.log("updated Weightage", weightagedetails);
        }
        if (this.currentMonth === month && this.currentYear === year) {
            weightagedetails.weightage = weightagevalue;
        }
        if (this.currentMonth != month && this.currentYear === (year + 1)) {
            console.log('new year');
        }
        // return weightagedetails
    }
    /**  method to check whether the month is currrent month code ends here */



}





// else {
        //     console.log("all divisions are listed", this.divisionList);
        //     console.log("selectedDivision",this.selectedDivision);

        //     /**code to get weightage */
        //     this._adminService.getWeigtagesByID(this.selectedDivision._id).subscribe((weightage) => {
        //         this.isRequesting = true;
        //         let divisionWeightage = weightage;
        //         if (divisionWeightage) {
        //             this.divisionWeightage = divisionWeightage;
        //             console.log('weightage', this.divisionWeightage);
        //             this.previousMonth = this.divisionWeightage.date
        //             //var month=this.previousMonth.getFullYear();


        //             var month = new Date(this.previousMonth);//
        //             console.log(month);

        //             this.previousMonthDivisionWeightage = this.divisionWeightage.weightage;
        //             this.currentMonthDivisionWeightage = this.previousMonthDivisionWeightage;
        //             this.isRequesting = false;
        //         }
        //     });
        //     /**code ends here */
        // }

  /**  method to check whether the month is currrent month code starts here */
    // checkForAvailablityOfCurrentMonthData() {
    //     var date = new Date(this.previousMonth);
    //     var month = date.getMonth();
    //     var year = date.getFullYear();
    //     if (this.currentMonth != month && this.currentYear === year) {
    //         this.divisionWeightage[0].weightageData.push({ date: new Date(this.currentTime).toISOString(), weightagevalue: this.currentMonthDivisionWeightage })
    //         console.log("this.divisionWeightage", this.divisionWeightage);
    //     }
    //     if (this.currentMonth === month && this.currentYear === year) {
    //         this.previousMonthDivisionWeightage = this.currentMonthDivisionWeightage;
    //     }
    //     if (this.currentMonth != month && this.currentYear === (year + 1)) {
    //         console.log('new year');
    //     }
    // }
    /**  method to check whether the month is currrent month code starts here */


    // public myForm: FormGroup;
    // public submitted: boolean;
    // public events: any[] = [];

    // constructor(private _fb: FormBuilder) { }

    // ngOnInit() {
    //     // the long way
    //     // this.myForm = new FormGroup({
    //     //     name: new FormControl('', [<any>Validators.required, <any>Validators.minLength(5)]),
    //     //     address: new FormGroup({
    //     //         address1: new FormControl('', <any>Validators.required),
    //     //         postcode: new FormControl('8000')
    //     //     })
    //     // });

    //     // the short way
    //     this.myForm = this._fb.group({
    //         name: ['', [<any>Validators.required, <any>Validators.minLength(5)]],
    //         address: this._fb.group({
    //             street: ['', <any>Validators.required],
    //             postcode: ['8000']
    //         })
    //     });

    //     // subscribe to form changes  
    //     this.subcribeToFormChanges();

    //     // Update single value
    //     (<FormControl>this.myForm.controls['name'])
    //         .setValue('John', { onlySelf: true });

    //     // Update form model
    //     // const people = {
    //     // 	name: 'Jane',
    //     // 	address: {
    //     // 		street: 'High street',
    //     // 		postcode: '94043'
    //     // 	}
    //     // };

    //     // (<FormGroup>this.myForm)
    //     //     .setValue(people, { onlySelf: true });

    // }

    // subcribeToFormChanges() {
    //     const myFormStatusChanges$ = this.myForm.statusChanges;
    //     const myFormValueChanges$ = this.myForm.valueChanges;

    //     myFormStatusChanges$.subscribe(x => this.events.push({ event: 'STATUS_CHANGED', object: x }));
    //     myFormValueChanges$.subscribe(x => this.events.push({ event: 'VALUE_CHANGED', object: x }));
    // }

    // save(model: User, isValid: boolean) {
    //     this.submitted = true;
    //     console.log(model, isValid);
    // }



