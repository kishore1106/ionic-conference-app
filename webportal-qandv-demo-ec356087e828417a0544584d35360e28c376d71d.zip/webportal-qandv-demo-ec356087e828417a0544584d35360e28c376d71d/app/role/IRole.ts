export interface IRole {
    id: string;
    role: string;
}