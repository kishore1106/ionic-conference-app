export class AppSettings {
   public static get API_URL(): string { return 'http://localhost:8001/'; }
}