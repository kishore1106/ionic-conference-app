


export class Constants {

  CLIENT_ID = "ForestProHarvest_client";
	 LOGIN_URL = "https://fedloginqa.cat.com/as/authorization.oauth2";
	 LOGOUT_URL = "";
	 REDIRECT_URI = "https://localhost.cat.com:8080/";
	 AUTHENTICATED_URLS = /((dspappservice\.azurewebsites\.net)|(services-qa|fedloginqa)\.cat\.com)/;
	 AUTHENTICATED_URLS_EXCEPTIONS = "";

}