import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';

import { IQuality } from './IQuality';
import {AppSettings} from '../appSettings';
import {DataWrapperService} from '.././common/dataWrapper.service';

@Injectable()
export class QualityDataService {

    constructor(private http: Http, private dataWrapper: DataWrapperService ) { }

    getQualityDetails(teamId, year) {
        return this.dataWrapper.getData(`${AppSettings.API_URL}teams/${teamId}/quality?year=${year}`);
    }
    updateQualityDetails(qualityDetails) {
        return this.dataWrapper.pushData(`${AppSettings.API_URL}teams/${ qualityDetails.teamId}/quality`, qualityDetails.qualityData);
    }

    getQualityDetailsfromdb(teamID: string) {
         return this.dataWrapper.getData(`${AppSettings.API_URL}teams/${teamID}/quality`);
    }
    getQualityDetailsWithoutYear(teamId) {
        return this.dataWrapper.getData(`${AppSettings.API_URL}teams/${teamId}/quality`);
    }
    getSectionNameBySectionId(sectionID: string) {
        return this.dataWrapper.getData(`${AppSettings.API_URL}sections/${sectionID}`);
    }
}

// above is the testuserquality.json reponse json for corresponding team id 
// GET api/v1/teams/teamid/quality