export interface IQualityData {
	year: string;
	month: string;
	defects: number;
	defectsExtAcsd: number;
	defectsExtCat: number;
}