import { Component, OnInit, Input, SimpleChange, EventEmitter, Output } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { AdminService } from '../admin/admin.service';
import { MultiselectDropdown, IMultiSelectOption, IMultiSelectSettings } from './multiselect-dropdown';
import { GenericFilterService } from '.././generic-filter/generic.filter.service';
import { RoleComponent } from '.././role/role.component';
import { IList } from '.././generic-filter/./generic-selector/IList';
import { IDepartment } from '.././generic-filter/IDepartment';
import { IDivision } from '.././generic-filter/IDivision';
import { ISection } from '.././generic-filter/ISection';
import { ITeam } from '.././generic-filter/ITeam';
import { IUser } from '.././generic-filter/IUser';


@Component({
    // moduleId: module.id,
    selector: 'my-multi-selector',
    templateUrl: 'ng2-multiselect/multi.select.component.html',


})
export class MultiSelectComponent implements OnInit {
    constructor(private _genericfilterservice: GenericFilterService, private _adminService: AdminService) { }
    tempTeams: any = [];
    tempSections: any = [];
    @Input() tempdivisions: any = [];
    checkAll: boolean;
    unCheckedAll: boolean;
    cwsId: any = "chennj";//ss14 koduvsachennj
    department: any = [];
    divisions: Array<any> = [];
    sections: Array<any> = [];
    teams: Array<any> = [];
    role: string;
    disableSection: boolean;
    firstName: any;
    lastName: any;
    disableDivision: boolean;
    disableDepartment: boolean;
    reportDivisions: any;
    reportDepartment: any;
    reportTeams: any;
    reportSections: any;
    division: any = [];
    section: any = [];
    temptem: any = [];

    currentTime = new Date();
    year: any = this.currentTime.getFullYear();
    years: any = [
        { id: this.currentTime.getFullYear() },
        { id: this.currentTime.getFullYear() - 1 }


    ];
    @Input() disableTeam: boolean;
    @Output() selectedListOutput: EventEmitter<Array<IList>> = new EventEmitter<Array<IList>>();
    @Output() disableEdit = new EventEmitter();
    @Output() loggedInUserRole: EventEmitter<any> = new EventEmitter<any>();
    @Output() yearToQaulityAndVelocity: EventEmitter<any> = new EventEmitter<any>();
    @Output() yearToReports: EventEmitter<any> = new EventEmitter<any>();
    @Input() report: boolean = false;
    @Output() selectedlistofsections: EventEmitter<Array<IList>> = new EventEmitter<Array<IList>>();
    @Output() selectedlistofdivisions: EventEmitter<Array<IList>> = new EventEmitter<Array<IList>>();
    @Output() userdetail: EventEmitter<any> = new EventEmitter<any>();

    showAgrregation: any = {
        showDepartmentAggregation: false,
        showDivisionAgrregation: false,
        showSectionAgrregation: false,
        sectionaggregatedvalue: false,
        divisionaggregatedvalue: false,
        departmentaggregatedvalue: false
    };
    departmentLevelReports: boolean = false;
    divisionLevelReports: boolean = false;
    sectionLevelReports: boolean = false;
    teamLevelReports: boolean = false;
    disabledepartmentdropdown: boolean = false;
    disabledivisiondropdown: boolean = false;
    disablesectiondropdown: boolean = false;
    disableteamdropdown: boolean = false;

    ngOnChanges(changes: { [propertyName: string]: SimpleChange }) {
    }
    ngOnInit() {
        //this.selectedRoleId("1"); //Hard coded roleId for initialization
        this.selectedRoleId();

    }
    private selectedRoleId(): void {
        this._genericfilterservice.getDetails(this.cwsId).subscribe((_users: any) => {
            let user: any = _users;
            console.log("user", user);
            if (user) {
                this.firstName = user.firstName;
                this.lastName = user.lastName;
                console.log(this.firstName, this.lastName);
                this.userdetail.emit(user);
                //check the role for dropdown
                this.setValueBasedOnUserRole(user);
                this.checkAll = true;
            }
            else if (user == null) {
                this.setValueIncaseOfUserNotAvailable();
            }
        });
    }

    private setValueBasedOnUserRole(user: any) {
        let userRole: String = (user.role).toLowerCase();
        switch (userRole) {
            case 'team member':
            case 'team lead':
                this.setTeamLevelData(user);
                break;

            case 'section coordinator':
            case 'supervisor':
                this.setSectionLevelData(user);
                break;

            case 'division manager':
                this.setDivisionLevelData(user);
                break;
            case 'department manager':
                this.setDepartmentLevelData(user);
                break;
            default:
                console.log("The User Role is not matched");
        }
    }

    private setValueIncaseOfUserNotAvailable() {
        this.reportSection();
        this.teamLevelReports = false;
        this.sectionLevelReports = false;
        this.divisionLevelReports = false;
        this.departmentLevelReports = true;
        this.disabledepartmentdropdown = false;
        this.disablesectiondropdown = true;
        this.disabledivisiondropdown = true;
        this.disableteamdropdown = true;
    }
    private setTeamLevelData(user: any) {
        this.role = 'Team Member';
        this.teams = user.teams;
        this.tempTeams = this.teams.map((team) => team);
        this.reportSection();
        this.disableDivision = true;
        this.disableSection = true;
        this.disableTeam = true;
        this.disableDepartment = true;
        this.disableEdit.emit(false);
        console.log("role at if", user.role);
        this.showAgrregation.showDepartmentAggregation = false;
        this.showAgrregation.showDivisionAgrregation = false;
        this.showAgrregation.showSectionAgrregation = false;
        this.showAgrregation.aggregation = false;
        this.loggedInUserRole.emit(this.showAgrregation);
    }
    private setSectionLevelData(user: any) {
        this.sectionLevelReports = false
        //this.onClickdepartmentLevelReportsCheckBox();
        this.onClicksectionLevelReportsCheckBox();
        // this.role = 'Supervisor';
        this.divisions = [];
        this.sections = [];
        this.teams = [];
        this.sections = user.sections.map((section) => section);
        this.tempSections = this.sections.map((section) => section);
        this._genericfilterservice.getTeams(this.sections[0]._id).subscribe((_teams: Array<any>) => {
            let team = _teams;
            this.teams = team.map((team) => team);
            this.tempTeams = this.teams.map((team) => team);
            this.disableDivision = true;
            this.disableSection = true;
            this.disableTeam = false;
            this.disableDepartment = true;
        });
        this.reportSection();
        this.showAgrregation.showDepartmentAggregation = false;
        this.showAgrregation.showDivisionAgrregation = false;
        this.showAgrregation.showSectionAgrregation = true;
        this.showAgrregation.sectionaggregatedvalue = true;
        this.loggedInUserRole.emit(this.showAgrregation);
    }
    private setDivisionLevelData(user: any) {
        this.onClickdivisionLevelReportsCheckBox();
        this.role = 'Division Manager';
        this.divisions = user.divisions;
        this.tempdivisions = this.divisions.map((division) => division);

        this._genericfilterservice.getSections(this.divisions[0]._id).subscribe((_sections: Array<any>) => {
            let section = _sections;
            this.sections = section;
            this.tempSections = this.sections.map((section) => section);
            this.teams = [];
            this.getTeamsBySectionID(0, this.sections);
        });
        this.reportSection();
        this.disableDivision = false;
        this.disableSection = false;
        this.disableTeam = false;
        this.disableDepartment = true;
        this.showAgrregation.showDepartmentAggregation = false;
        this.showAgrregation.showDivisionAgrregation = true;
        this.showAgrregation.showSectionAgrregation = true;
        this.showAgrregation.divisionaggregatedvalue = true;
        this.loggedInUserRole.emit(this.showAgrregation);
    }
    private setDepartmentLevelData(user: any) {
        this.role = 'Department Manager';
        this.onClickdepartmentLevelReportsCheckBox();
        this.department = user.departments;
        this._genericfilterservice.getDivisions(this.department[0]._id).subscribe((_divisions: Array<any>) => {
            this.divisions = _divisions;
            this.tempdivisions = this.divisions.map((division) => division);
            this.getDivisionsSectionsAndCoresspondingTeams(this.divisions);
        });
        this.reportSection();
        this.role = 'Department Manager';
        this.disableDivision = false;
        this.disableSection = false;
        this.disableTeam = false;
        this.disableDepartment = false;
        this.showAgrregation.showDepartmentAggregation = true;
        this.showAgrregation.showDivisionAgrregation = true;
        this.showAgrregation.showSectionAgrregation = true;
        this.showAgrregation.departmentaggregatedvalue = true;
        this.loggedInUserRole.emit(this.showAgrregation);
    }

    private getDivisionsSectionsAndCoresspondingTeams(divisionIDs: any) {
        this.getSectionsByDivisionID(0, divisionIDs);
    }

    private getSectionsByDivisionID(index: number, divisionIDs: any) {
        if (index == divisionIDs.length) {
            this.sections = this.tempSections.map((section) => section);
            return this.getTeamsBySectionID(0, this.sections);
        }
        this._genericfilterservice.getSections(divisionIDs[index]._id).subscribe((_sections: Array<any>) => {
            if (_sections) {
                this.tempSections = [...this.tempSections, ..._sections];
            }
            index += 1;
            this.getSectionsByDivisionID(index, divisionIDs);
        });
    }

    private getTeamsBySectionID(index: number, sectionIDs: any) {
        if (index == sectionIDs.length) {
            this.teams = this.tempTeams.map((team) => team);
            return;
        }
        this._genericfilterservice.getTeams(sectionIDs[index]._id).subscribe((_teams: Array<any>) => {
            if (_teams) {
                this.tempTeams = [...this.tempTeams, ..._teams];
            }
            index += 1;
            this.getTeamsBySectionID(index, sectionIDs);
        });
    }

    private reportSection() {
        this._adminService.getAllDepartment().subscribe((department) => {
            let departmentlist = department;
            if (departmentlist) {
                this.reportDepartment = departmentlist;
            }
        });

        this._adminService.getAllDivisions().subscribe((division) => {

            let divisionlist = division;
            if (divisionlist) {
                this.reportDivisions = divisionlist;
                console.log(this.reportDivisions);

            }
        });
        this._adminService.getAllSections().subscribe((sections) => {
            let sectionlist = sections;
            if (sectionlist) {
                this.reportSections = sectionlist;
            }
        });
        this._adminService.getAllTeams().subscribe((teams) => {

            let teamlist = teams;
            if (teamlist) {
                this.reportTeams = teamlist;
            }
        });

    }

    selectedoptions(data: any) {
        var list = data.selectedList;
        console.log('list at emited multi-sec', list);
        this.division = [];//check condition here
        this.section = [];
        if (data.unChecked) {
            this.setValueForUnCheckedAll(data.source);
        } else {
            this.checkAll = true;
            this.unCheckedAll = false;
            if (typeof (list) != "undefined" && list.length > 0) {
                this.setValueBasedOnType(data.source, list);
            }
            else {
                this.listBecameEmpty(list, data.source);
            }
        }
    }

    private setValueBasedOnType(sourceType: string, list: Array<any>) {
        if (this.isDivision(sourceType)) {
            this.setValueForDivisionDropDown(list);
        }
        else if (this.isSection(sourceType)) {
            this.setValueForSectionDropDown(list);
            this.disableSection = false;
        }
        else if (this.isTeam(sourceType)) {
            this.setValueForTeamDropDown(list);
            this.disableTeam = false;
        }
    }
    
    private setValueForUnCheckedAll(sourceType: string) {
        this.disableDataBasedOnSourceType(sourceType);
        this.selectedListOutput.emit([]);
    }

    private setValueForDivisionDropDown(list: any) {
        list.forEach((item) => {
            this.division = [...this.division, ...(this.divisions.filter((division: any) => division._id === item._id))];
            this.sections = [];
            if (this.division.length > 0) {
                this.division.forEach((division) => {
                    this.sections = [...this.sections, ...this.tempSections.filter((section) => section.divisionId === division._id)];
                });
            }
        });
    }
    private setValueForSectionDropDown(list: any) {
        list.forEach((item) => {
            this.section = [...this.section, ...(this.sections.filter((section: any) => section._id === item._id))];
            this.teams = [];
            if (this.section.length > 0) {
                this.section.forEach((section) => {
                    this.teams = [...this.teams, ...this.tempTeams.filter((team) => team.sectionId === section._id)];
                });
            }
        });
    }
    private setValueForTeamDropDown(list: any) {
        list.forEach((item) => {
            this.selectedListOutput.emit(list);//we get here array of teams
            this.selectedlistofsections.emit(this.tempSections);
            this.selectedlistofdivisions.emit(this.tempdivisions);
        });
    }

    private listBecameEmpty(list, sourceType: string) {
        this.disableDataBasedOnSourceType(sourceType);
        this.selectedListOutput.emit(list);
    }

    private disableDataBasedOnSourceType(sourceType: string) {
        if (this.isDivision(sourceType))
            this.disableSectionsAndTeams();
        else if (this.isSection(sourceType))
            this.disableTeams();
    }

    private disableTeams() {
        this.teams = [{}];
        this.disableTeam = true;
    }
    private disableSectionsAndTeams() {
        this.teams = [{}];
        this.sections = [{}];
        this.disableSection = true;
        this.disableTeam = true;
    }

    private isDivision(sourceType: string) {
        return (sourceType === 'division') ? true : false;
    }
    private isSection(sourceType: string) {
        return (sourceType === 'section') ? true : false;
    }
    private isTeam(sourceType: string) {
        return (sourceType === 'team') ? true : false;
    }

    optionsUpdated(data) {
        console.log('Selected data ', data);
    }
    onSelectYear(yearId) {
        this.year = yearId;
        this.yearToQaulityAndVelocity.emit(yearId);
        // this.getDetails();
        console.log("year selected", this.year);
        this.yearToReports.emit(yearId);
    }
    onClickdepartmentLevelReportsCheckBox() {
        if (this.departmentLevelReports != true) {
            this.departmentLevelReports = true;
            this.divisionLevelReports = false;
            this.sectionLevelReports = false;
            this.teamLevelReports = false;
            this.disableteamdropdown = true;
            this.disabledepartmentdropdown = false;
            this.disabledivisiondropdown = true;
            this.disablesectiondropdown = true;

        }
        else {
            this.departmentLevelReports = false;
        }
    }
    onClickdivisionLevelReportsCheckBox() {
        if (this.divisionLevelReports != true) {
            this.divisionLevelReports = true;
            this.disabledepartmentdropdown = true
            this.disabledivisiondropdown = false;
            this.disablesectiondropdown = true;
            this.teamLevelReports = false;
            this.disableteamdropdown = true;
            this.departmentLevelReports = false;
            this.sectionLevelReports = false;
        }
        else {
            this.divisionLevelReports = false;
        }
    }
    onClicksectionLevelReportsCheckBox() {
        if (this.sectionLevelReports != true) {
            this.sectionLevelReports = true;
            this.disabledepartmentdropdown = true
            this.disabledivisiondropdown = true;
            this.disablesectiondropdown = false;
            this.disableteamdropdown = true;
            this.teamLevelReports = false;
            this.divisionLevelReports = false;
            this.departmentLevelReports = false;
        }
        else {
            this.sectionLevelReports = false;
        }

    }
    onClickTeamLevelReportsCheckBox() {
        if (this.teamLevelReports != true) {
            this.teamLevelReports = true;
            this.disableteamdropdown = false;
            this.disabledepartmentdropdown = true;
            this.disabledivisiondropdown = true;
            this.disablesectiondropdown = true;
            this.divisionLevelReports = false;
            this.departmentLevelReports = false;
            this.sectionLevelReports = false;
        }
        else {
            this.teamLevelReports = false;
        }
    }
    selectedoptionsforreport(selectedId) {
        console.log("SSSSSSSSSSSSSSSSEELLLLLLLLEccctteeddd", selectedId);
        this.selectedListOutput.emit(selectedId);
    }
}