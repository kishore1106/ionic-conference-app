# ng2 Seed Project



 Angula2 Seed Project with Webpack and TypeScript
 
 ## Prerequisites

1. Install [Node.js](http://nodejs.org)
 - on OSX use [homebrew](http://brew.sh) `brew install node`
 - on Windows use [chocolatey](https://chocolatey.org/) `choco install nodejs`

2. Install webpack 'npm install -g webpack'

3. Install webpack-dev-server npm install -g webpack-dev-server

### Installing Packages
After you clone the project you should run the below command, but if you notice missing packages, run these again:

-'npm install'

After npm install is complete run the below command:

-'typings install' 

## Running the Seed Project
 To run the project you run the below command
 
  -'webpack-dev-server --inline'
 
## License
TBD