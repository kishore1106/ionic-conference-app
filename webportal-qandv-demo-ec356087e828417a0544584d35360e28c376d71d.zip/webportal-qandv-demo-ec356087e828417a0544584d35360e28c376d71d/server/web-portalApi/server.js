/**
 * Created by ravi
 */
process.env.NODE_ENV = process.env.NODE_ENV || "development";
//process.env.NODE_ENV = process.env.NODE_ENV || "test";

// Express configuration
var express = require('./config/express');
var config = require('./config/config');
var mongoose = require('mongoose');
var schedule = require('node-schedule');
var request = require('request');

var Sections = require('../web-portalApi/app/sections/models/sections.model');
var Divisions = require('../web-portalApi/app/division/models/divisions.model');

var QualityReports = require('../web-portalApi/app/reports/models/quality.reports.model');
var VelocityReports = require('../web-portalApi/app/reports/models/velocity.reports.model');

var DivisionQualityReports = require('../web-portalApi/app/reports/models/division.quality.reports');
var DivisionVelocityReports = require('../web-portalApi/app/reports/models/division.velocity.reports');


var fs = require('fs'),
    https = require('https'),
//express = require('express'),
    app = express();

// var app = express();


mongoose.Promise = global.Promise;
mongoose.connect(config.db);
var connection = mongoose.connection;

connection.on('error', function (err) {
    console.log('mongodb connection error: %s', err);
    process.exit();
});
connection.on('open', function () {
    console.log('Successfully connected to mongodb');

});

var j = schedule.scheduleJob({hour: 15, minute: 02}, function () {

    var year = (new Date()).getFullYear();

    Sections.find({}, {_id: 1}).exec(function (err, sections) {
        console.log(sections);
        sections.forEach(function (item, index) {
            request({
                url: "http://localhost:8001/sections/" + item._id + "/quality/reports?year="+year,
                method: "GET"
            }, function (err, response, body) {

                if (!err && response) {
                    QualityReports.findOneAndRemove({"sectionId": item._id}, function (error, count) {
                        if (!error) {
                            var report = new QualityReports(JSON.parse(response.body));
                            report.save(function (err, report) {
                                if (!err) {
                                    console.log("quality report saved");

                                } else {
                                    next(err);
                                }
                            });
                        }

                    });


                }
                else {
                    res.status(401).send("unauthorized");
                }
            });
            request({
                url: "http://localhost:8001/sections/" + item._id + "/velocity/reports?year="+year,
                method: "GET"
            }, function (err, response, body) {

                if (!err && response) {
                    VelocityReports.findOneAndRemove({"sectionId": item._id}, function (error, count) {
                        if (!error) {
                            var report = new VelocityReports(JSON.parse(response.body));
                            report.save(function (err, report) {
                                if (!err) {
                                    console.log("velocity report saved");

                                } else {
                                    next(err);
                                }
                            });
                        }

                    });


                }
                else {
                    res.status(401).send("unauthorized");
                }
            });
        });
    });

//    Divisions.find({}, {_id: 1}).exec(function (err, divisions) {
//        divisions.forEach(function (item, index) {
//            request({
//                url: "http://localhost:8001/divisions/" + item._id + "/quality/reports",
//                method: "GET"
//            }, function (err, response, body) {

//                if (!err && response) {
//                    DivisionQualityReports.findOneAndRemove({"divisionId": item._id}, function (error, count) {
//                        if (!error) {
//                            var report = new DivisionQualityReports(JSON.parse(response.body));
//                            report.save(function (err, report) {
//                                if (!err) {
//                                    console.log("division quality report saved");

//                                } else {
//                                    next(err);
//                                }
//                            });
//                        }

//                    });


//                }
//                else {
//                    res.status(401).send("unauthorized");
//                }
//            });
//            request({
//                url: "http://localhost:8001/divisions/" + item._id + "/velocity/reports",
//                method: "GET"
//            }, function (err, response, body) {

//                if (!err && response) {
//                    DivisionVelocityReports.findOneAndRemove({"divisionId": item._id}, function (error, count) {
//                        if (!error) {
//                            var report = new DivisionVelocityReports(JSON.parse(response.body));
//                            report.save(function (err, report) {
//                                if (!err) {
//                                    console.log("division velocity report saved");

//                                } else {
//                                    next(err);
//                                }
//                            });
//                        }

//                    });


//                }
//                else {
//                    res.status(401).send("unauthorized");
//                }
//            });
//        });
//    });
});


app.get('/ss', function (req, res, next) {
    res.end('index');
});


var server = app.listen(8001);
/**below code is used for https Api calls  starts*/
// https.createServer({
//   key: fs.readFileSync('key.pem'),
//   cert: fs.readFileSync('cert.pem')
// }, app).listen(8001);
/**below code is used for https Api calls ends */

module.exports = app;

console.log("Server running at 8001");