/**
 * Created by Selotsoft on 03/06/15.
 */


//define(['angular', 'angularMocks', 'sharedModule'], function () {
//
//    var mockModalSvc, countryCodesObj;
//
//    beforeEach(function ($provide) {
//
//    });
//
//    it('should countrycode is making a api call', function () {
//
//    });
//});