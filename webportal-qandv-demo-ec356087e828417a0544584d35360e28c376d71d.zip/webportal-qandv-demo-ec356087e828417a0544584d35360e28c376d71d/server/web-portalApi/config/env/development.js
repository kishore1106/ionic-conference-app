module.exports = {
    db:"mongodb://10.91.7.51:27017/webportal"
};
//        mongodb://[username:password@]host1[:port1][,host2[:port2],...[,hostN[:portN]]][/[database][?options]]