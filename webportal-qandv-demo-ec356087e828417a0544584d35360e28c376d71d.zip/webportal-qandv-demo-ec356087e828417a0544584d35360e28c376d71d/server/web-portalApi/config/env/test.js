

module.exports = {


    db:"mongodb://localhost/test"

};

//        mongodb://[username:password@]host1[:port1][,host2[:port2],...[,hostN[:portN]]][/[database][?options]]

