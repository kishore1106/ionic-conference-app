(function() {
  'use strict';

  angular.module('blocks.logger', []);
})();
