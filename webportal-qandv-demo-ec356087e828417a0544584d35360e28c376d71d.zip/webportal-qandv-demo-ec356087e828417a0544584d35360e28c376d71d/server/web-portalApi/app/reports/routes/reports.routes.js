
var reportsController = require('../../reports/controllers/reports.controller.js');

module.exports = function (app) {

    app.route('/teams/:teamId/quality/reports')
        .get( reportsController.getTeamQualityReportsData);

    app.route('/teams/:teamId/velocity/reports')
        .get( reportsController.getTeamVelocityReportsData);


    app.route('/sections/:sectionId/quality/reports')
        .get( reportsController.getQualityReportsData);

    app.route('/sections/:sectionId/velocity/reports')
        .get( reportsController.getVelocityReportsData);

    app.route('/divisions/:divisionId/quality/reports')
        .get( reportsController.getDivisionQualityReports);

    app.route('/divisions/:divisionId/velocity/reports')
        .get( reportsController.getDivisionVelocityReports);

    app.route('/departments/:departmentId/quality/reports')
        .get( reportsController.getDepartmentQualityReports);

    app.route('/departments/:departmentId/velocity/reports')
        .get( reportsController.getDepartmentVelocityReports);



};
