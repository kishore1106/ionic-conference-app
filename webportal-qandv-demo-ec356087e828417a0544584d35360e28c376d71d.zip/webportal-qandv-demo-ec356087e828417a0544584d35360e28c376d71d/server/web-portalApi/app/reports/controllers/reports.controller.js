var Weightages = require('../.././weightage/models/weightage.model');
var Qualities = require('../.././quality/models/quality.model');
var Velocities = require('../.././velocity/models/velocity.model');
var VelocityReports = require('../.././reports/models/velocity.reports.model');
var QualityReports = require('../.././reports/models/quality.reports.model');
var DivisionQualityReports = require('../.././reports/models/division.quality.reports');
var DivisionVelocityReports = require('../.././reports/models/division.velocity.reports');
var mongoose = require('mongoose');

exports.getTeamQualityReportsData = function (req, res, next) {

    var year = req.query.year;

    var start = new Date(year, 0);
    var end = new Date(year, 12);


    var query;
    if (!year) {
        query = Qualities.find({
            teamId: req.params.teamId
        });
    } else {
        query = Qualities.aggregate(
            {
                $unwind: "$qualityData"
            }, {
                $match: {
                    "teamId": mongoose.Types.ObjectId(req.params.teamId),
                    "qualityData.date": {
                        $gte: start,
                        $lte: end
                    }
                }
            },
            { $group: { _id: '$_id', divisionId: { $first: '$divisionId' },
                sectionId: { $first: '$sectionId' },
                teamId: { $first: '$teamId' }, departmentId: { $first: '$departmentId' }, actual: { $first: '$actual' }, goal: { $first: '$goal' }, qualityData: { $push: '$qualityData' } } }
        );
    }

    var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    query.exec(function (err, teamQuality) {
        var qualityDetails = teamQuality[0];

        if (!err && qualityDetails) {

            var totaldefects = 0;
            qualityDetails.aggrExtCat = 0;
            qualityDetails.aggrExtAcsd = 0;
            qualityDetails.qualityData.forEach(function (qualityDataForEachMonth, index) {
                qualityDataForEachMonth.month = new Date(qualityDataForEachMonth.date).getMonth();
                qualityDataForEachMonth.label = months[new Date(qualityDataForEachMonth.date).getMonth()];
                qualityDataForEachMonth.qualitytargetval = 25;
                totaldefects = totaldefects + qualityDataForEachMonth.defects;
                var avgDefects = totaldefects / (index + 1);
                qualityDetails.aggrExtCat = qualityDetails.aggrExtCat + qualityDataForEachMonth.defectsExtCat;
                qualityDetails.aggrExtAcsd = qualityDetails.aggrExtAcsd + qualityDataForEachMonth.defectsExtAcsd;
                qualityDataForEachMonth.qualityImprovementPercentage = (qualityDetails.actual - (avgDefects * 12)) / qualityDetails.actual;
            });
            res.status(200).json(qualityDetails);


        } else {
            next(err);
        }
    });


};
exports.getTeamVelocityReportsData = function (req, res, next) {
    var year = req.query.year;
    var start = new Date(year, 0);
    var end = new Date(year, 12);
    var query;

    if (!year) {
        query = Velocities.find({
            teamId: req.params.teamId
        });
    } else {
        query = Velocities.aggregate({ $match: { teamId: mongoose.Types.ObjectId(req.params.teamId) } },
            { $unwind: '$velocityData' },
            { $match: { 'velocityData.date': { $gt: start, $lt: end } } },
            { $group: { _id: '$_id', divisionId: { $first: '$divisionId' },
                sectionId: { $first: '$sectionId' },
                teamId: { $first: '$teamId' }, departmentId: { $first: '$departmentId' }, cycleTime: { $first: '$cycleTime' }, velocityData: { $push: '$velocityData' } } });
    }

    var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];


    query.exec(function (err, teamVelocity) {
        var velocityDetails = teamVelocity[0];

        if (!err && velocityDetails) {
            var totalODT = 0;
            var totalCycleTime = 0;
            velocityDetails.velocityData.forEach(function (velocityDataForEachMonth, index) {
                velocityDataForEachMonth.month = new Date(velocityDataForEachMonth.date).getMonth();
                velocityDataForEachMonth.label = months[new Date(velocityDataForEachMonth.date).getMonth()];
                velocityDataForEachMonth.productivityTargetval = 25;
                totalCycleTime = totalCycleTime + velocityDataForEachMonth.cumulativeCycTime;
                totalODT = totalODT + velocityDataForEachMonth.deliveredOnTimeRelease;
                var avgCycleTime = totalCycleTime / (index + 1);
                velocityDataForEachMonth.onTimeDelivery = totalODT / (index + 1);
                velocityDataForEachMonth.productiveImprovement = (velocityDetails.cycleTime - avgCycleTime ) / velocityDetails.cycleTime;
            });
            res.status(200).json(velocityDetails);


        } else {
            next(err);
        }
    });
};

exports.getVelocityReportsData = function (req, res, next) {
    var year = req.query.year;
    var start = new Date(year, 0);
    var end = new Date(year, 12);
    var query;

    if (!year) {
        query = Velocities.find({
            sectionId: req.params.sectionId
        });
    } else {
        query = Velocities.aggregate({ $match: { sectionId: mongoose.Types.ObjectId(req.params.sectionId) } },
            { $unwind: '$velocityData' },
            { $match: { 'velocityData.date': { $gt: start, $lt: end } } },
            { $group: { _id: '$_id', divisionId: { $first: '$divisionId' },
                sectionId: { $first: '$sectionId' },
                teamId: { $first: '$teamId' }, departmentId: { $first: '$departmentId' }, cycleTime: { $first: '$cycleTime' }, velocityData: { $push: '$velocityData' } } });
    }

    var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];


    query.exec(function (err, velocityDetails) {

        if (!err) {
            var teamIds = [];

            velocityDetails.forEach(function (velocityDataForEachTeam) {
                teamIds.push(velocityDataForEachTeam.teamId);
            });
            Weightages.aggregate({
                    $match: {
                        source: {
                            $in: teamIds
                        }
                    }
                },

                {
                    $group: {

                        _id: {
                            source: "$source"
                        },
                        "source": {$push: "$weightage"}
                    }
                }, {
                    $project: {
                        source: "$_id.source",
                        weightage: "$source",
                        _id: 0
                    }
                })
                .exec(function (err, weightages) {
                    velocityDetails.forEach(function (velocityDataForEachTeam, j) {

                        var temp = weightages.filter(function (obj) {
                            return (obj.source.toString() == velocityDataForEachTeam.teamId.toString());
                        });
                        var currentWeightage = temp[0].weightage;
                        var i = 0;
                        var onTimeDelivery = 0;
                        var velocityImprovement = 0;
                        velocityDataForEachTeam.velocityData.forEach(function (velocityDetailsForEachMonth, index) {
                            i = i + 1; //to count the number of months
                            velocityImprovement += velocityDetailsForEachMonth.cumulativeCycTime;
                            onTimeDelivery += velocityDetailsForEachMonth.deliveredOnTimeRelease;
                            velocityDetailsForEachMonth.productiveImprovement = (((velocityDataForEachTeam.cycleTime - (velocityImprovement / i)) / velocityDataForEachTeam.cycleTime) * 100) * currentWeightage[index];
                            velocityDetailsForEachMonth.onTimeDelivery = (onTimeDelivery / i);


                        });


                    });

                    var velocityResult = velocityDetails.reduce(function (previousTeam, currentTeam) {
                        var tempSection = {};
                        tempSection.sectionId = previousTeam.sectionId;
                        tempSection.divisionId = previousTeam.divisionId;
                        tempSection.departmentId = previousTeam.departmentId;
                        tempSection.cycleTime = previousTeam.cycleTime;
                        tempSection.velocityData = [];


                        previousTeam.velocityData.forEach(function (previousTeamMonthData, index) {
                            var monthData = {
                                date: previousTeamMonthData.date,
                                month: new Date(previousTeamMonthData.date).getMonth(),
                                label: months[new Date(previousTeamMonthData.date).getMonth()],
                                productiveImprovement: 0,
                                productivityTargetval: 25
                            };

                            var currentTeamMonthData = currentTeam.velocityData[index];

                            if (currentTeamMonthData) {
                                monthData.onTimeDelivery = ((previousTeamMonthData.onTimeDelivery + currentTeamMonthData.onTimeDelivery) / velocityDetails.length);
                                monthData.productiveImprovement = previousTeamMonthData.productiveImprovement + currentTeamMonthData.productiveImprovement;
                                tempSection.velocityData.push(monthData);
                            }


                        });
                        return tempSection;


                    });

                    res.status(200).json(velocityResult);
                });


        }
        else {
            next(err);
        }
    });

};

exports.getQualityReportsData = function (req, res, next) {


    var reports = {};
    reports.data = [];
    var year = req.query.year;

    var start = new Date(year, 0);
    var end = new Date(year, 12);


    var query;
    if (!year) {
        query = Qualities.find({
            sectionId: req.params.sectionId
        });
    } else {
        query = Qualities.aggregate(
            {
                $unwind: "$qualityData"
            }, {
                $match: {
                    "sectionId": mongoose.Types.ObjectId(req.params.sectionId),
                    "qualityData.date": {
                        $gte: start,
                        $lte: end
                    }
                }
            },
            { $group: { _id: '$_id', divisionId: { $first: '$divisionId' },
                sectionId: { $first: '$sectionId' },
                teamId: { $first: '$teamId' }, departmentId: { $first: '$departmentId' }, actual: { $first: '$actual' }, goal: { $first: '$goal' }, qualityData: { $push: '$qualityData' } } }
        );
    }

    var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    query.exec(function (err, qualityData) {
        if (!err) {


//            var tempSection = {};
            if (qualityData.length > 1) {
                var qualityResult = qualityData.reduce(function (previousTeam, currentTeam) {

//                    console.log(previousTeam);
                    var tempSection = {};
                    tempSection.sectionId = previousTeam.sectionId;
                    tempSection.divisionId = previousTeam.divisionId;
                    tempSection.departmentId = previousTeam.departmentId;

                    tempSection.actual = (previousTeam.actual + currentTeam.actual);
                    tempSection.qualityData = [];
                    tempSection.aggrExtCat = 0;
                    tempSection.aggrExtAcsd = 0;
                    var i = 0;
                    var y = 0;
                    var previousMonthDefects = 0;
                    var currentMonthDefects = 0;

                    previousTeam.qualityData.forEach(function (previousTeamMonthData, index) {
                        i = i + 1;
                        var monthData = {
                            date: previousTeamMonthData.date,
                            month: new Date(previousTeamMonthData.date).getMonth(),
                            label: months[new Date(previousTeamMonthData.date).getMonth()],
                            projected: 0,
                            qualitytargetval: 25,
                            qualityImprovementPercentage: 0,
                            defects: 0,
                            defectsExtAcsd: 0,
                            defectsExtCat: 0
                        };

                        var currentTeamMonthData = currentTeam.qualityData[index];
                        if (currentTeamMonthData) {
                            y = y + 1;
                            previousMonthDefects += previousTeamMonthData.defects;
                            currentMonthDefects += currentTeamMonthData.defects;

                            var avgTotal = ((previousMonthDefects / i) * 12) + ((currentMonthDefects / y) * 12);
                            monthData.defects = previousTeamMonthData.defects + currentTeamMonthData.defects;


                            monthData.qualityImprovementPercentage = ((tempSection.actual - avgTotal) / tempSection.actual) * 100;

                            monthData.defectsExtAcsd = previousTeamMonthData.defectsExtAcsd + currentTeamMonthData.defectsExtAcsd;
                            monthData.defectsExtCat = previousTeamMonthData.defectsExtCat + currentTeamMonthData.defectsExtCat;
                            tempSection.aggrExtCat += monthData.defectsExtCat;
                            tempSection.aggrExtAcsd += monthData.defectsExtAcsd;
                            tempSection.qualityData.push(monthData);
                        }

                    });
//                    console.log(tempSection);

                    return tempSection;
                });
                res.json(qualityResult);
            }


        } else {
            next(err);
        }
    });


};


exports.getDivisionQualityReports = function (req, res, next) {
    // var year = req.query.year;
    // var start = new Date(year, 0);
    // var end = new Date(year, 12);
    var query;
    var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];


    // if (!year) {
    query = QualityReports.find({
        divisionId: req.params.divisionId
    });

    query.exec(function (err, sectionReports) {
        if (!err) {
            var sectionIds = [];

            sectionReports.forEach(function (reportForEachSection) {
                sectionIds.push(mongoose.Types.ObjectId(reportForEachSection.sectionId));
            });
            Weightages.aggregate({
                    $match: {
                        source: {
                            $in: sectionIds
                        }
                    }
                },

                {
                    $group: {

                        _id: {
                            source: "$source"
                        },
                        "source": {$push: "$weightage"}
                    }
                }, {
                    $project: {
                        source: "$_id.source",
                        weightage: "$source",
                        _id: 0
                    }
                })
                .exec(function (err, weightages) {
//                    console.log(weightages);
                    sectionReports.forEach(function (reportForEachSection, j) {

                        var temp = weightages.filter(function (obj) {
                            return (obj.source.toString() == reportForEachSection.sectionId.toString());
                        });
                        var currentWeightage = temp[0].weightage;

                        reportForEachSection.qualityData.forEach(function (qualityMonth, index) {


                            qualityMonth.qualityImprovementPercentage = qualityMonth.qualityImprovementPercentage * currentWeightage[index];

                        });


                    });

                    var qualityResult = sectionReports.reduce(function (previousTeam, currentTeam) {

                        var tempSection = {};
                        tempSection.divisionId = previousTeam.divisionId;
                        tempSection.departmentId = previousTeam.departmentId;

                        tempSection.qualityData = [];
                        tempSection.aggrExtCat = 0;
                        tempSection.aggrExtAcsd = 0;

                        previousTeam.qualityData.forEach(function (previousSectionMonthData, index) {
                            var monthData = {
                                date: previousSectionMonthData.date,
                                month: new Date(previousSectionMonthData.date).getMonth(),
                                label: months[new Date(previousSectionMonthData.date).getMonth()],
                                projected: 0,
                                qualitytargetval: 25,
                                qualityImprovementPercentage: 0,
                                defects: 0,
                                defectsExtAcsd: 0,
                                defectsExtCat: 0
                            };

                            var currentSectionMonthData = currentTeam.qualityData[index];
                            if (currentSectionMonthData) {

                                monthData.defects = previousSectionMonthData.defects + currentSectionMonthData.defects;

                                monthData.qualityImprovementPercentage = (previousSectionMonthData.qualityImprovementPercentage) + (currentSectionMonthData.qualityImprovementPercentage);
                                monthData.defectsExtAcsd = previousSectionMonthData.defectsExtAcsd + currentSectionMonthData.defectsExtAcsd;
                                monthData.defectsExtCat = previousSectionMonthData.defectsExtCat + currentSectionMonthData.defectsExtCat;
                                tempSection.aggrExtCat += monthData.defectsExtCat;
                                tempSection.aggrExtAcsd += monthData.defectsExtAcsd;
                                tempSection.qualityData.push(monthData);
                            }

                        });

                        return tempSection;
                    });

                    res.status(200).json(qualityResult);
                });


        } else {
            next(err);
        }
    });

};

exports.getDivisionVelocityReports = function (req, res, next) {
    // var year = req.query.year;
    // var start = new Date(year, 0);
    // var end = new Date(year, 12);
    var query;
    var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];


    // if (!year) {
    query = VelocityReports.find({
        divisionId: req.params.divisionId
    });

    query.exec(function (err, sectionReports) {
        if (!err) {
            var sectionIds = [];

            sectionReports.forEach(function (reportForEachSection) {
                sectionIds.push(mongoose.Types.ObjectId(reportForEachSection.sectionId));
                console.log(sectionIds);
            });
            Weightages.aggregate({
                    $match: {
                        source: {
                            $in: sectionIds
                        }
                    }
                },

                {
                    $group: {

                        _id: {
                            source: "$source"
                        },
                        "source": {$push: "$weightage"}
                    }
                }, {
                    $project: {
                        source: "$_id.source",
                        weightage: "$source",
                        _id: 0
                    }
                })
                .exec(function (err, weightages) {
                    console.log(weightages);
                    sectionReports.forEach(function (reportForEachSection, j) {

                        var temp = weightages.filter(function (obj) {
                            return (obj.source.toString() == reportForEachSection.sectionId.toString());
                        });
                        var currentWeightage = temp[0].weightage;

                        reportForEachSection.velocityData.forEach(function (velocityMonth, index) {


                            velocityMonth.productiveImprovement = velocityMonth.productiveImprovement * currentWeightage[index];
                            velocityMonth.onTimeDelivery = velocityMonth.onTimeDelivery / sectionReports.length;

                        });


                    });

                    var velocityResult = sectionReports.reduce(function (previousTeam, currentTeam) {

                        var tempSection = {};
                        tempSection.divisionId = previousTeam.divisionId;
                        tempSection.departmentId = previousTeam.departmentId;

                        tempSection.velocityData = [];

                        previousTeam.velocityData.forEach(function (previousSectionMonthData, index) {
                            var monthData = {
                                date: previousSectionMonthData.date,
                                month: new Date(previousSectionMonthData.date).getMonth(),
                                label: months[new Date(previousSectionMonthData.date).getMonth()],
                                projected: 0,
                                productivityTargetval: 10,
                                productiveImprovement: 0
                            };

                            var currentSectionMonthData = currentTeam.velocityData[index];
                            if (currentSectionMonthData) {

                                monthData.onTimeDelivery = (previousSectionMonthData.onTimeDelivery + currentSectionMonthData.onTimeDelivery);
                                monthData.productiveImprovement = (previousSectionMonthData.productiveImprovement) + (currentSectionMonthData.productiveImprovement);
                                tempSection.velocityData.push(monthData);
                            }

                        });

                        return tempSection;
                    });

                    res.status(200).json(velocityResult);
                });


        } else {
            next(err);
        }
    });

};

exports.getDepartmentQualityReports = function (req, res, next) {
    // var year = req.query.year;
    // var start = new Date(year, 0);
    // var end = new Date(year, 12);
    var query;
    var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];


    // if (!year) {
    query = DivisionQualityReports.find({
        departmentId: req.params.departmentId
    });

    query.exec(function (err, divisionReports) {
//        console.log(divisionReports);

        if (!err) {
            divisionReports.forEach(function (reportForEachDivision, j) {


                reportForEachDivision.qualityData.forEach(function (qualityMonth, index) {


                    qualityMonth.qualityImprovementPercentage = qualityMonth.qualityImprovementPercentage / divisionReports.length;

                });


            });

            var qualityResult = divisionReports.reduce(function (previousDivision, currentDivision) {

                var tempSection = {};
                tempSection.departmentId = previousDivision.departmentId;

                tempSection.qualityData = [];
                tempSection.aggrExtCat = 0;
                tempSection.aggrExtAcsd = 0;

                previousDivision.qualityData.forEach(function (previousDivisionMonthData, index) {
                    var monthData = {
                        date: previousDivisionMonthData.date,
                        month: new Date(previousDivisionMonthData.date).getMonth(),
                        label: months[new Date(previousDivisionMonthData.date).getMonth()],
                        projected: 0,
                        qualitytargetval: 25,
                        qualityImprovementPercentage: 0,
                        defects: 0,
                        defectsExtAcsd: 0,
                        defectsExtCat: 0
                    };

                    var currentDivisionMonthData = currentDivision.qualityData[index];
                    if (currentDivisionMonthData) {

                        monthData.defects = previousDivisionMonthData.defects + currentDivisionMonthData.defects;

                        monthData.qualityImprovementPercentage = (previousDivisionMonthData.qualityImprovementPercentage) + (currentDivisionMonthData.qualityImprovementPercentage);
                        monthData.defectsExtAcsd = previousDivisionMonthData.defectsExtAcsd + currentDivisionMonthData.defectsExtAcsd;
                        monthData.defectsExtCat = previousDivisionMonthData.defectsExtCat + currentDivisionMonthData.defectsExtCat;
                        tempSection.aggrExtCat += monthData.defectsExtCat;
                        tempSection.aggrExtAcsd += monthData.defectsExtAcsd;
                        tempSection.qualityData.push(monthData);
                    }

                });

                return tempSection;
            });

            res.status(200).json(qualityResult);
        } else {
            next(err);
        }
    });

};

exports.getDepartmentVelocityReports = function (req, res, next) {
    // var year = req.query.year;
    // var start = new Date(year, 0);
    // var end = new Date(year, 12);
    var query;
    var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];


    // if (!year) {
    query = DivisionVelocityReports.find({
        departmentId: req.params.departmentId
    });

    query.exec(function (err, divisionReports) {
        if (!err) {
            divisionReports.forEach(function (reportForEachDivision, j) {


                reportForEachDivision.velocityData.forEach(function (velocityMonth, index) {


                    velocityMonth.productiveImprovement = velocityMonth.productiveImprovement / divisionReports.length;
                    velocityMonth.onTimeDelivery = velocityMonth.onTimeDelivery / divisionReports.length;

                });


            });

            var velocityResult = divisionReports.reduce(function (previousDivision, currentDivision) {

                var tempSection = {};
                tempSection.departmentId = previousDivision.departmentId;

                tempSection.velocityData = [];

                previousDivision.velocityData.forEach(function (previousDivisionMonthData, index) {
                    var monthData = {
                        date: previousDivisionMonthData.date,
                        month: new Date(previousDivisionMonthData.date).getMonth(),
                        label: months[new Date(previousDivisionMonthData.date).getMonth()],
                        projected: 0,
                        productivityTargetval: 10,
                        productiveImprovement: 0
                    };

                    var currentDivisionMonthData = currentDivision.velocityData[index];
                    if (currentDivisionMonthData) {

                        monthData.onTimeDelivery = (previousDivisionMonthData.onTimeDelivery + currentDivisionMonthData.onTimeDelivery);
                        monthData.productiveImprovement = (previousDivisionMonthData.productiveImprovement) + (currentDivisionMonthData.productiveImprovement);
                        tempSection.velocityData.push(monthData);
                    }

                });

                return tempSection;
            });

            res.status(200).json(velocityResult);


        } else {
            next(err);
        }
    });

};



