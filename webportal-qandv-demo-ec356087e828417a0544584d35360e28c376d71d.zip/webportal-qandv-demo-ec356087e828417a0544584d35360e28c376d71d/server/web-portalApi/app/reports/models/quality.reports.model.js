// grab the things we need
var mongoose = require('mongoose');
var Schema = mongoose.Schema;

// create a schema
var qualityReportsSchema = new Schema({
    sectionId: {type: String, required: true },
    divisionId: {type: String, required: true },
    actual: {type: Number},
    aggrExtCat: {type: Number},
    aggrExtAcsd: {type: Number},
    goal: {type: Number},
    qualityData:[{
        date:{type: Date},
        month:Number,
        label:String,
        projected:Number,
        qualitytargetval:Number,
        qualityImprovementPercentage:Number,
        defects:Number,
        defectsExtAcsd:Number,
        defectsExtCat:Number
    }]

});

// the schema is useless so far
// we need to create a model using it
var qualityReports = mongoose.model('QualityReports', qualityReportsSchema);

// make this available to our users in our Node applications
module.exports = qualityReports;