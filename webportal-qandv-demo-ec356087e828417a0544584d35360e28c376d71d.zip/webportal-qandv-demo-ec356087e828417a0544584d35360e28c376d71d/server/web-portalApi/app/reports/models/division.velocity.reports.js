// grab the things we need
var mongoose = require('mongoose');
var Schema = mongoose.Schema;

// create a schema
var divisionReportsSchema = new Schema({
    divisionId: {type: String, required: true },
    departmentId: {type: String, required: true},

    velocityData: [
        {
            date: Date,
            month: Number,
            label: String,
            projected: Number,
            productivitytargetval: Number,
            productiveImprovement: Number,
            onTimeDelivery: Number
        }
    ]

});

// the schema is useless so far
// we need to create a model using it
var divisionReports = mongoose.model('DivisionVelocityReports', divisionReportsSchema);

// make this available to our users in our Node applications
module.exports = divisionReports;