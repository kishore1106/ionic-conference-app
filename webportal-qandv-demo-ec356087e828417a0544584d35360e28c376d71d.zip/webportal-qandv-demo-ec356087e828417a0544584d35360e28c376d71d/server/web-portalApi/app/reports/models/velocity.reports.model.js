// grab the things we need
var mongoose = require('mongoose');
var Schema = mongoose.Schema;

// create a schema
var velocityReportsSchema = new Schema({
    sectionId: {type: String, required: true },
    divisionId: {type: String, required: true },
    cycleTime: {type: Number },
    velocityData:[{
        date:{type: Date},
        month:Number,
        label:String,
        onTimeDelivery:Number,
        productiveImprovement:Number,
        productivityTargetval:Number
    }]

});

// the schema is useless so far
// we need to create a model using it
var velocityReports = mongoose.model('VelocityReports', velocityReportsSchema);

// make this available to our users in our Node applications
module.exports = velocityReports;