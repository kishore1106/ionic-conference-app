var Weightage = require('../models/weightage.model');
var Qualities = require('../.././quality/models/quality.model');
var Velocities = require('../.././velocity/models/velocity.model');
// var Divisions = require('../.././division/models/divisions.model');

// create a new user called chris


exports.getLatestWeightage = function (req, res, next) {
    
    // Weightage.find({"source": req.params.teamId}).sort({"date": -1}).exec(function (err, result) {
    //     if(!err){
    //        res.status(200).json(result[0]);
    //     }else{
    //         next(err);
    //     }
    // });
    Weightage.find({"source": req.params.Id}).sort({"date": 1}).exec(function (err, result) {
        if(!err){
           res.status(200).json(result);
        }else{
            next(err);
        }
    });
};

exports.updateWeightageById = function (req,res,next) {
     Weightage.findOne({
        _id: req.params.Id
    }, function (err, result) {
        if (!err) {
            result.weightage = req.body.weightage;
            result.save(function (err,updatedobject) {
                if(err){
                    console.log(err);
                    res.status(500).send();
                }
                else{
                    res.send(updatedobject);
                }
            });
           
        } else {
            next(err);
        }
    });
};






exports.create = function (req, res, next) {
    var weightage = new Weightage(req.body);

    // call the built-in save method to save to the database
    weightage.save(function (err, result) {
        if (!err) {

            res.status(201).json(result.toObject());
        } else {
            next(err);
        }
    });
};
exports.getWeightage = function (req, res, next) {
    var weightageDetails;
    var velocityMonth;
    var velocityYear;
    var weightageMonth;
    var weightageYear;
    var velocityDetailsForTeam;
    var _velocityDataForEachMonth = {};
    var velocityDataWithWeightage = [];
    var weightage;
    var weightageSource;
    var weightageObject = {
        "0": 0,
        "1": 0,
        "2": 0,
        "3": 0,
        "4": 0,
        "5": 0,
        "6": 0,
        "7": 0,
        "8": 0,
        "9": 0,
        "10": 0,
        "11": 0


    };
    var velocityDataForEachMonth = {};
    var months = [];
    velocityDataForEachMonth.weightage = '';
    var year = req.query.year;
    console.log(req.query.year);
    var startDtFormat = year + '-01-01';
    var endDtFormat = year + '-12-31';
    var startDate = new Date(startDtFormat).toISOString();
    var endDate = new Date(endDtFormat).toISOString();
    // console.log(req.params.teamId + ' ' + startDate + ' ' + endDate);
    Weightage.find({
        source: req.params.teamId,
        date: {
            $gte: startDate,
            $lte: endDate
        }
    })
        .sort({
            date: 1
        })
        .exec(function (err, weightageDetails) {
            console.log('Sort date ', weightageDetails);
            weightageDetails.forEach(function (weightageForEachMonth) {
                //console.log(weightageForEachMonth);
                // weightageSource = weightageForEachMonth.source;
                weightage = weightageForEachMonth.weightage;
                weightageMonth = new Date(weightageForEachMonth.date).getMonth();
                weightageObject[weightageMonth] = weightage;
                months.push(weightageMonth);
                weightageObject[weightageMonth]
                weightageYear = new Date(weightageForEachMonth.date).getFullYear();
            });

            for (var i = 0; i <= 11; i++) {
                if (weightageObject[i] == 0) {
                    weightageObject[i] = weightageObject[i - 1];
                }
            }
            console.log("weigthageObject", weightageObject);
            console.log(weightageObject);
            var velocityData = [];
            Velocities.find({ teamId: req.params.teamId }, function (err, velocityDetails) {
                velocityDetails = velocityDetails[0].toObject();

                velocityDetails.velocityData.forEach(function (velocityDataForEachMonth) {
                    months.forEach(function (month) {
                        for (var i = 0; i <= 11; i++) {
                            // if (((velocityMonth = new Date(velocityDataForEachMonth.date).getMonth()) == month) &&
                            // ((velocityYear = new Date(velocityDataForEachMonth.date).getFullYear()) == weightageYear))
                            {
                                // // _velocityDataForEachMonth = {};
                                // _velocityDataForEachMonth = velocityDataForEachMonth.toObject();
                                // // _velocityDataForEachMonth.weightage = weightageObject[months];
                                // // velocityDataWithWeightage.push(_velocityDataForEachMonth);
                                // // console.log(velocityDataWithWeightage);

                                velocityDataForEachMonth.weightage = weightageObject[i];
                                // velocityData.push(_velocityDataForEachMonth);
                                // console.log('Inside if loop ', _velocityDataForEachMonth);
                            }
                        }
                    });
                });
                console.log("Weightage ", velocityDetails);
                res.json(velocityDetails);
            });
        });
};
// exports.updateWeightageByDivisionId = function (req,res,next) {
//      Weightage.findOne({
//         source: req.params.divisionId
//     }, function (err, result) {
//         if (!err) {
//             result.weightage = req.body.weightage;
//             result.date = req.body.date;
//             result.save(function (err,updatedobject) {
//                 if(err){
//                     console.log(err);
//                     res.status(500).send();
//                 }
//                 else{
//                     res.send(updatedobject);
//                 }
//             });
           
//         } else {
//             next(err);
//         }
//     });
// };
// exports.getWeightageByDivisionId = function (req,res,next) {

//       var query = Weightage.find({source:req.params.divisionId});
//     query.exec(function(err, divisionWeightage) {
//         if (!err) {
//             res.status(200).json(divisionWeightage);
//         } else {
//             next(err);
//         }
//     });
// };
// exports.getWeightageByTeamId = function (req,res,next) {

//       var query = Weightage.find({source:req.params.teamId});
//     query.exec(function(err, teamWeightage) {
//         if (!err) {

//             res.status(200).json(divisionWeightage);
//         } else {
//             next(err);
//         }
//     });
// };