// grab the things we need
var mongoose = require('mongoose');
var Schema = mongoose.Schema;

// create a schema

var sectionsSchema = new Schema({
    name: {type: String, required: true},
    divisionId: {type: Schema.ObjectId, ref: 'divisions', required: true }

});
var Sections = mongoose.model('Sections', sectionsSchema);
module.exports = Sections;