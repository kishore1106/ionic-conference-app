var Teams = require('../models/teams.model');
var Velocities = require('../.././velocity/models/velocity.model');
var actualAndGoal = require('../.././actualAndGoal/models/actualAndGoal.model');
var Qualities = require('../.././quality/models/quality.model');
var QualityReports = require('../.././reports/models/quality.reports.model');
var VelocityReports = require('../.././reports/models/velocity.reports.model');
var Section = require('../.././sections/models/sections.model');
var Division = require('../.././division/models/divisions.model');
var mongoose = require('mongoose');
var request = require('request');

// create a new user called chris
var teams = new Teams({
    name: 'Telematics',
    sectionId: '57d7d9c77423bbd02502dce9'
});

exports.create = function (req, res, next) {

    // call the built-in save method to save to the database
    teams.save(function (err, result) {
        if (!err) {
            res.status(201).json(result.toObject());
        } else {
            next(err);
        }
    });
};

exports.getTeamsDetails = function (req, res, next) {
    // get all the users
    var query = Teams.find();
    query.exec(function (err, teamsDetails) {
        if (!err) {
            res.status(200).json(teamsDetails);
            res.end('teams')
        } else {
            next(err);
        }
    });
};
exports.getVelocityByTeam = function (req, res, next) {
    // get all the users
    var year = req.query.year;
    var start = new Date(year, 0);
    var end = new Date(year, 12);
    var query;

    if (!year) {
        query = Velocities.find({
            teamId: req.params.teamId
        });
    } else {
        query = Velocities.aggregate({ $match: { teamId: mongoose.Types.ObjectId(req.params.teamId) } },
            { $unwind: '$velocityData' },
            { $match: { 'velocityData.date': { $gt: start, $lt: end } } },
            { $group: { _id: '$_id', divisionId: { $first: '$divisionId' },
                sectionId: { $first: '$sectionId' },
                teamId: { $first: '$teamId' }, departmentId: { $first: '$departmentId' }, velocityData: { $push: '$velocityData' } } });
    }


    //    var query = Qualities.findOne({teamId: req.params.teamId, 'qualityData.date': {$gte: start, $lte: end}});
    query.exec(function (err, velocity) {
        if (!err) {

            res.status(200).json(velocity);
        } else {
            next(err);
        }
    });
};

exports.updateVelocityByTeam = function (req, res, next) {


    Velocities.findOneAndUpdate({
        teamId: req.params.teamId
    }, {
        "velocityData": req.body
    }, {
        new: true
    }, function (err, result) {
        if (!err) {
//            res.status(200).json(result);
            request({
                url: "http://localhost:8001/sections/" + result.sectionId + "/velocity/reports?year=2016",
                method: "GET"
            }, function (err, response, body) {

                if (!err && response) {
                    VelocityReports.findOneAndRemove({"sectionId": result.sectionId}, function (error, count) {
//                        console.log(count);
                        if (!error) {
                            var report = new VelocityReports(JSON.parse(response.body));
                            report.save(function (err, report) {
                                if (!err) {
                                    res.status(201).json(report.toObject());
                                } else {
                                    next(err);
                                }
                            });
                        }

                    });


                }
                else {
                    res.status(401).send("unauthorized");
                }
            });
        } else {
            next(err);
        }
    });
};
exports.getVelocityBySection = function (req, res, next) {
    // get all the users
    var year = req.query.year;
    var start = new Date(year, 0);
    var end = new Date(year, 12);
    var query;

    if (!year) {
        query = Velocities.find({
            sectionId: req.params.sectionId
        });
    } else {
        query = Velocities.aggregate({ $match: { sectionId: mongoose.Types.ObjectId(req.params.sectionId) } },
            { $unwind: '$velocityData' },
            { $match: { 'velocityData.date': { $gt: start, $lt: end } } },
            { $group: { _id: '$_id', divisionId: { $first: '$divisionId' },
                sectionId: { $first: '$sectionId' },
                teamId: { $first: '$teamId' }, departmentId: { $first: '$departmentId' }, velocityData: { $push: '$velocityData' } } });
    }
    query.exec(function (err, velocity) {
        if (!err) {
            res.status(200).json(velocity);
        } else {
            next(err);
        }
    });
};

// need to work
exports.updateVelocityBySection = function (req, res, next) {

    Velocities.findOneAndUpdate({
        sectionId: req.params.sectionId
    }, {
        "velocityData": req.body
    }, {
        new: true
    }, function (err, result) {
        if (!err) {
            res.status(200).json(result);
        } else {
            next(err);
        }
    });
};

exports.getVelocityByDivision = function (req, res, next) {
    // get all the users
    var query = Velocities.find({
        divisionId: req.params.divisionId
    });
    query.exec(function (err, velocity) {
        if (!err) {
            res.status(200).json(velocity);
        } else {
            next(err);
        }
    });
};

exports.updateVelocityByDivision = function (req, res, next) {

    Velocities.findOneAndUpdate({
        divisionId: req.params.divisionId
    }, {
        "velocityData": req.body
    }, {
        new: true
    }, function (err, result) {
        if (!err) {
            res.status(200).json(result);
        } else {
            next(err);
        }
    });
};
exports.getQualityByTeam = function (req, res, next) {
    // get all the users
    var year = req.query.year;

    var start = new Date(year, 0);
    var end = new Date(year, 12);


    var query;
    if (!year) {
        query = Qualities.find({
            teamId: req.params.teamId
        });
    } else {
        query = Qualities.aggregate({ $match: { teamId: mongoose.Types.ObjectId(req.params.teamId) } },
            { $unwind: '$qualityData' },
            { $match: { 'qualityData.date': { $gte: start, $lte: end } } },
            { $group: { _id: '$_id', divisionId: { $first: '$divisionId' },
                sectionId: { $first: '$sectionId' },
                teamId: { $first: '$teamId' }, departmentId: { $first: '$departmentId' }, qualityData: { $push: '$qualityData' } } });
    }


    //    var query = Qualities.findOne({teamId: req.params.teamId, 'qualityData.date': {$gte: start, $lte: end}});
    query.exec(function (err, quality) {
        if (!err) {

            res.status(200).json(quality);
        } else {
            next(err);
        }
    });
};

exports.updateQualityByTeam = function (req, res, next) {


    Qualities.findOneAndUpdate({
        teamId: req.params.teamId
    }, {
        "qualityData": req.body
    }, {
        new: true
    }, function (err, result) {
        if (!err) {
//            res.status(200).json(result);

            request({
                url: "http://localhost:8001/sections/" + result.sectionId + "/quality/reports",
                method: "GET"
            }, function (err, response, body) {

                if (!err && response) {
                    QualityReports.findOneAndRemove({"sectionId": result.sectionId}, function (error, count) {
//                        console.log(count);
                        if (!error) {
                            var report = new QualityReports(JSON.parse(response.body));
                            report.save(function (err, report) {
                                if (!err) {
                                    res.status(201).json(report.toObject());
                                } else {
                                    next(err);
                                }
                            });
                        }

                    });


                }
                else {
                    res.status(401).send("unauthorized");
                }
            });


        } else {
            next(err);
        }
    });
};

exports.updateCycleTime = function (req, res, next) {

    Velocities.findOneAndUpdate({
        teamId: req.params.teamId
    }, {$set: {"cycleTime": req.body.cycleTime}}, function (err, result) {
        if (!err) {

            res.status(200).json(result);
        } else {
            next(err);
        }
    });
};


exports.moveTeam = function (req, res, next) {
    Teams.findByIdAndUpdate(req.params.teamId, req.body, {new: true}, function (err, result) {
        if(!err){
            res.status(200).json(result);
        }else{
            next(err);
        }

    });
};

exports.moveSection = function (req, res, next) {
    Section.findByIdAndUpdate(req.params.sectionId, req.body, {new: true}, function (err, result) {
        if(!err){
            res.status(200).json(result);
        }else{
            next(err);
        }
    });
};

exports.getQualityBySection = function (req, res, next) {
    var year = req.query.year;

    var start = new Date(year, 0);
    var end = new Date(year, 12);


    var query;
    if (!year) {
        query = Qualities.find({
            sectionId: req.params.sectionId
        });
    } else {
        query = Qualities.aggregate(
            {
                $unwind: "$qualityData"
            }, {
                $match: {
                    "sectionId": mongoose.Types.ObjectId(req.params.sectionId),
                    "qualityData.date": {
                        $gte: start,
                        $lte: end
                    }
                }
            },
            { $group: { _id: '$_id', divisionId: { $first: '$divisionId' },
                sectionId: { $first: '$sectionId' },
                teamId: { $first: '$teamId' }, departmentId: { $first: '$departmentId' }, qualityData: { $push: '$qualityData' } } }
        );
    }


    //    var query = Qualities.findOne({teamId: req.params.teamId, 'qualityData.date': {$gte: start, $lte: end}});
    query.exec(function (err, quality) {
        if (!err) {

            res.status(200).json(quality);
        } else {
            next(err);
        }
    });
};

exports.updateQualityBySection = function (req, res, next) {

    Qualities.findOneAndUpdate({
        sectionId: req.params.sectionId
    }, {
        "qualityData": req.body
    }, {
        new: true
    }, function (err, result) {
        if (!err) {
            res.status(200).json(result);
        } else {
            next(err);
        }
    });
};

exports.getQualityByDivision = function (req, res, next) {
    // get all the users
    var query = Qualities.find({
        divisionId: req.params.divisionId
    });
    query.exec(function (err, quality) {
        if (!err) {
            res.status(200).json(quality);
        } else {
            next(err);
        }
    });
};

exports.updateQualityByDivision = function (req, res, next) {

    Qualities.findOneAndUpdate({
        divisionId: req.params.divisionId
    }, {
        "qualityData": req.body
    }, {
        new: true
    }, function (err, result) {
        if (!err) {
            res.status(200).json(result);
        } else {
            next(err);
        }
    });
};