var actualController = require('../../actualAndGoal/controllers/actualAndGoal.controller.js');

module.exports = function (app) {

    app.route('/teams/:teamId/actualandgoal')
        .post(actualController.create);
    app.route('/actualAndGoal/:teamId')
        .get(actualController.getTeamActualAndGoal);

};
