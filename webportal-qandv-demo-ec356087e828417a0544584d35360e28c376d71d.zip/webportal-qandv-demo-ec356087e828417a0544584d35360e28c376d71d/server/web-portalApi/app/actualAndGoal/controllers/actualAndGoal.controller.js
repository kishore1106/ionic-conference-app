var actualAndGoal = require('../models/actualAndGoal.model');
var Qualities = require('../.././quality/models/quality.model');
var mongoose = require('mongoose');
// var Qualities = require('../.././quality/models/quality.model');

// var Divisions = require('../.././division/models/divisions.model');

// create a new user called chris
var ag = new actualAndGoal({
        source: ('57d7d8e02d2db9f01fe2833e'),
        actual: 21,
        goal: 23,
        year: 2016
    }
);

exports.create = function (req, res, next) {

    Qualities.findOneAndUpdate({
        teamId: req.params.teamId
    }, {$set: {"actual": req.body.actual,
        "goal": req.body.goal}}, function (err, result) {
        if (!err) {

            res.status(200).json(result);
        } else {
            next(err);
        }
    });
};


exports.getTeamActualAndGoal = function (req, res, next) {
    var year = req.query.year;

    var start = new Date(year, 0, 1);
    var end = new Date(year, 11, 31);
    Qualities.find({
        teamId: req.params.teamId

    }, {actual: 1, goal: 1, teamId: 1})

        .exec(function (err, actualDetails) {

            console.log(actualDetails);
            if (!err) {
                res.status(200).json(actualDetails);
            }


        });

};



