// function find(list, sublist) { 
//     for(var i = 0, length =  list.length; i<length; i++) {
//         if(list.join('') == sublist.join('')) {
//             return i;
//         }
//         list.shift();
//     }
//     return -1;
// }