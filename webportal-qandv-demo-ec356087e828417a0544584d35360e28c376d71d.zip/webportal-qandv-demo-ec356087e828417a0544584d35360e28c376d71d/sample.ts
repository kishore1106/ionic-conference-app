// teams.reduce(function(prevTeam, currTeam) {
//     prevTeam.velocityData.forEach((velocityMonth, i)=> {
//         velocityMonth.otd += currTeam.velocityData[i].otd; 
//     })
//     return prevTeam;
// })

// months.reduce(function(prevMonth, currMonth, i) {
//     if(i === 0) {
//         prevMonth.average = ((prevMonth.value+currMonth.value)/i+1);
//     }
//     currMonth.average = ((prevMonth.value+currMonth.value)/i+1);
//     var newMonth.value = ((prevMonth.value+currMonth.value)/i+1);
//    return newMonth;
// }, {value: 0})